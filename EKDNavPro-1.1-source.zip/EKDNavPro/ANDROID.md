# EKDNavPro para Android

La app Android conserva la interfaz web y usa un servicio nativo en primer plano para mantener el GPS y la conexión BLE con EKD01 mientras la pantalla está apagada. La navegación automática fuera de ruta se aplica a rutas calculadas por la app; las rutas GPX no se recalculan automáticamente. La voz se controla desde el botón de la interfaz y usa la síntesis de voz de Android.

## Requisitos

- Node.js y npm
- JDK 21
- Android SDK con Android API 36 y Build Tools 36

## Compilar

Desde la carpeta del proyecto:

```powershell
npm.cmd install
npm.cmd run android:sync
$env:JAVA_HOME = "C:\ruta\a\jdk-21"
$env:ANDROID_HOME = "$env:LOCALAPPDATA\Android\Sdk"
.\android\gradlew.bat -p android :app:assembleDebug
```

El APK de depuración se genera en `android\app\build\outputs\apk\debug\app-debug.apk`.

Al iniciar la navegación, concede ubicación precisa y notificaciones. Android mostrará una notificación persistente mientras el servicio está activo. La ruta y los mapas requieren conexión para calcularse; los mapas vectoriales descargados siguen disponibles offline dentro del límite configurado.

La compilación del APK no sustituye la prueba física: hay que comprobar en el teléfono y con un EKD01 que el GPS, las instrucciones BLE y el recálculo sigan funcionando con la pantalla bloqueada. Algunos fabricantes también aplican restricciones propias de batería.
