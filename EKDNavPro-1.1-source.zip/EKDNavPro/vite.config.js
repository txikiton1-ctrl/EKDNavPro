import { defineConfig } from 'vite';
import { cpSync } from 'node:fs';
import { resolve } from 'node:path';

export default defineConfig({
  base: process.env.BASE_PATH || '/',
  build: {
    outDir: 'www',
    emptyOutDir: true
  },
  plugins: [{
    name: 'copy-android-assets',
    closeBundle() {
      const output = resolve('www');
      cpSync('sw.js', resolve(output, 'sw.js'));
      cpSync('manifest.json', resolve(output, 'manifest.json'));
      cpSync('icons', resolve(output, 'icons'), { recursive: true });
    }
  }]
});
