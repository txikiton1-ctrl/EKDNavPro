# BideBizi Web

Aplicación web de navegación para bicicleta.

## Ejecutar BideBizi

[Abrir la aplicación web](https://txikiton1-ctrl.github.io/BideBizi/)

## Desarrollo

```sh
npm ci
npx vite --host 127.0.0.1
```

## Compilación

```sh
npm run build
```

La compilación genera el sitio estático en `www/`. Para desplegarlo, usa `npm run build` como comando de compilación y `www` como directorio de salida.

El navegador necesita permiso de ubicación para el seguimiento GPS. El navegador puede suspender el seguimiento cuando la aplicación queda en segundo plano.

## Datos BRouter

Los segmentos `.rd5` se descargan primero a la carpeta Descargas del navegador. Después, usa **Importar .rd5 a BideBizi** para guardarlos en el almacenamiento local de ese navegador y dispositivo. El resumen de almacenamiento muestra la cantidad y el tamaño guardados; **Borrar datos guardados** elimina esos segmentos.

La importación local no sincroniza los archivos con otros dispositivos ni habilita el cálculo de rutas sin conexión. El cálculo de rutas sigue necesitando conexión a internet.
