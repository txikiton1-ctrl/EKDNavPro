package com.ekdnavpro.app;

import android.Manifest;
import android.app.DownloadManager;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;

import androidx.core.content.ContextCompat;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;

import org.json.JSONException;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@CapacitorPlugin(
    name = "EkdNav",
    permissions = {
        @Permission(alias = "bluetooth", strings = {Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT}),
        @Permission(alias = "location", strings = {Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}),
        @Permission(alias = "notifications", strings = {Manifest.permission.POST_NOTIFICATIONS}),
        @Permission(alias = "downloads", strings = {Manifest.permission.WRITE_EXTERNAL_STORAGE})
    }
)
public class EkdNavPlugin extends Plugin {
    private static volatile EkdNavPlugin instance;
    private static final Handler MAIN_HANDLER = new Handler(Looper.getMainLooper());
    private static final ExecutorService NATIVE_EXECUTOR = Executors.newSingleThreadExecutor();

    @Override
    public void load() {
        instance = this;
    }

    @PluginMethod
    public void connect(PluginCall call) {
        String address = call.getString("address", "").trim().toUpperCase();
        if (!address.matches("^([0-9A-F]{2}:){5}[0-9A-F]{2}$")) {
            call.reject("Introduce una dirección Bluetooth válida.");
            return;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            ContextCompat.checkSelfPermission(getContext(), Manifest.permission.BLUETOOTH_CONNECT) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissionForAlias("bluetooth", call, "bluetoothPermissionResult");
            return;
        }
        connectDevice(call, address);
    }

    @PermissionCallback
    private void bluetoothPermissionResult(PluginCall call) {
        if (getPermissionState("bluetooth") != PermissionState.GRANTED) {
            call.reject("Se necesita permiso de dispositivos cercanos para conectar con EKD01.");
            return;
        }
        connectDevice(call, call.getString("address", "").trim().toUpperCase());
    }

    private void connectDevice(PluginCall call, String address) {
        NATIVE_EXECUTOR.execute(() -> {
            try {
                EkdBleManager.getInstance(getContext()).connect(address);
                JSObject result = new JSObject();
                result.put("connected", true);
                call.resolve(result);
            } catch (Exception error) {
                emitConnectionState(false);
                call.reject(error.getMessage() == null ? "No se pudo conectar con EKD01." : error.getMessage(), error);
            }
        });
    }

    @PluginMethod
    public void write(PluginCall call) {
        JSArray values = call.getArray("data");
        if (values == null) {
            call.reject("No se recibieron datos BLE.");
            return;
        }
        try {
            byte[] data = new byte[values.length()];
            for (int i = 0; i < values.length(); i++) data[i] = (byte) values.getInt(i);
            NATIVE_EXECUTOR.execute(() -> {
                try {
                    EkdBleManager.getInstance(getContext()).write(data);
                    call.resolve();
                } catch (Exception error) {
                    call.reject(error.getMessage() == null ? "Falló la escritura BLE." : error.getMessage(), error);
                }
            });
        } catch (JSONException error) {
            call.reject("Los datos BLE deben ser una lista de bytes.", error);
        }
    }

    @PluginMethod
    public void downloadBrouterSegment(PluginCall call) {
        String url = call.getString("url", "");
        String filename = call.getString("filename", "");
        Uri uri = Uri.parse(url);
        if (!"https".equalsIgnoreCase(uri.getScheme()) ||
            !"brouter.de".equalsIgnoreCase(uri.getHost()) ||
            !("/brouter/segments4/" + filename).equals(uri.getPath()) ||
            !filename.matches("^[EW]\\d+_[NS]\\d+\\.rd5$")) {
            call.reject("La descarga no es un segmento BRouter válido.");
            return;
        }
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P &&
            getPermissionState("downloads") != PermissionState.GRANTED) {
            requestPermissionForAlias("downloads", call, "downloadPermissionResult");
            return;
        }
        enqueueBrouterSegmentDownload(call, uri, filename);
    }

    @PermissionCallback
    private void downloadPermissionResult(PluginCall call) {
        if (getPermissionState("downloads") != PermissionState.GRANTED) {
            call.reject("Se necesita permiso de almacenamiento para guardar datos BRouter.");
            return;
        }
        enqueueBrouterSegmentDownload(
            call,
            Uri.parse(call.getString("url", "")),
            call.getString("filename", "")
        );
    }

    private void enqueueBrouterSegmentDownload(PluginCall call, Uri uri, String filename) {
        DownloadManager manager = (DownloadManager) getContext().getSystemService(Context.DOWNLOAD_SERVICE);
        if (manager == null) {
            call.reject("Android no tiene disponible el gestor de descargas.");
            return;
        }
        try {
            DownloadManager.Request request = new DownloadManager.Request(uri)
                .setTitle(filename)
                .setDescription("Datos de BRouter")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, filename);
            long downloadId = manager.enqueue(request);
            JSObject result = new JSObject();
            result.put("downloadId", downloadId);
            call.resolve(result);
        } catch (RuntimeException error) {
            call.reject(error.getMessage() == null ? "No se pudo iniciar la descarga BRouter." : error.getMessage(), error);
        }
    }

    @PluginMethod
    public void disconnect(PluginCall call) {
        NATIVE_EXECUTOR.execute(() -> {
            EkdBleManager.getInstance(getContext()).disconnect();
            emitConnectionState(false);
            call.resolve();
        });
    }

    @PluginMethod
    public void startNavigation(PluginCall call) {
        if (getPermissionState("location") != PermissionState.GRANTED) {
            requestPermissionForAlias("location", call, "locationPermissionResult");
            return;
        }
        requestNotificationPermissionOrStart(call);
    }

    @PermissionCallback
    private void locationPermissionResult(PluginCall call) {
        if (getPermissionState("location") != PermissionState.GRANTED) {
            call.reject("Se necesita permiso de ubicación para navegar en segundo plano.");
            return;
        }
        requestNotificationPermissionOrStart(call);
    }

    private void requestNotificationPermissionOrStart(PluginCall call) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(getContext(), Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissionForAlias("notifications", call, "notificationPermissionResult");
            return;
        }
        startNavigationService(call);
    }

    @PermissionCallback
    private void notificationPermissionResult(PluginCall call) {
        startNavigationService(call);
    }

    private void startNavigationService(PluginCall call) {
        try {
            EkdNavigationService.start(getContext(), call.getData().toString());
            call.resolve();
        } catch (Exception error) {
            call.reject(error.getMessage() == null ? "No se pudo iniciar la navegación en segundo plano." : error.getMessage(), error);
        }
    }

    @PluginMethod
    public void stopNavigation(PluginCall call) {
        EkdNavigationService.stop(getContext());
        call.resolve();
    }

    @PluginMethod
    public void getNavigationStatus(PluginCall call) {
        call.resolve(EkdNavigationService.getStatus());
    }

    @PluginMethod
    public void setVoiceEnabled(PluginCall call) {
        EkdNavigationService service = EkdNavigationService.getCurrent();
        if (service != null) service.setVoiceEnabled(call.getBoolean("enabled", true));
        call.resolve();
    }

    static void emitConnectionState(boolean connected) {
        EkdNavPlugin plugin = instance;
        if (plugin == null) return;
        MAIN_HANDLER.post(() -> {
            JSObject data = new JSObject();
            data.put("connected", connected);
            plugin.notifyListeners("connectionState", data, true);
        });
    }

    static void emitNavigationEvent(String event, JSObject data) {
        EkdNavPlugin plugin = instance;
        if (plugin == null) return;
        MAIN_HANDLER.post(() -> plugin.notifyListeners(event, data));
    }

    static boolean hasLocationPermission(Context context) {
        return ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED;
    }
}
