package com.ekdnavpro.app;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.content.Context;
import android.os.Build;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.atomic.AtomicBoolean;

final class EkdBleManager {
    private static final String PREFERENCES = "ekdnav_bluetooth";
    private static final String ADDRESS_KEY = "address";
    private static final UUID SERVICE_UUID = UUID.fromString("6e400001-b5a3-f393-e0a9-e50e24dcca9e");
    private static final UUID TX_UUID = UUID.fromString("6e400002-b5a3-f393-e0a9-e50e24dcca9e");
    private static final UUID RX_UUID = UUID.fromString("6e400003-b5a3-f393-e0a9-e50e24dcca9e");
    private static final UUID CCCD_UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
    private static final byte[] AES_KEY = {50, 67, 84, 68, 85, 52, 48, 113, 78, 121, 67, 103, 84, 106, 98, 49};
    private static EkdBleManager instance;

    private final Context context;
    private final ScheduledExecutorService heartbeatExecutor = Executors.newSingleThreadScheduledExecutor();
    private final Object writeMutex = new Object();
    private final AtomicBoolean connecting = new AtomicBoolean();
    private volatile BluetoothGatt gatt;
    private volatile BluetoothGattCharacteristic txCharacteristic;
    private volatile BluetoothGattCharacteristic rxCharacteristic;
    private CountDownLatch readyLatch;
    private CountDownLatch writeLatch;
    private int writeStatus;
    private PendingResponse pendingResponse;
    private volatile boolean connected;
    private volatile boolean manualDisconnect;
    private volatile String lastAddress;
    private int reconnectAttempts;
    private ScheduledFuture<?> heartbeatTask;
    private ScheduledFuture<?> reconnectTask;

    static synchronized EkdBleManager getInstance(Context context) {
        if (instance == null) instance = new EkdBleManager(context.getApplicationContext());
        return instance;
    }

    private EkdBleManager(Context context) {
        this.context = context;
        lastAddress = context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE).getString(ADDRESS_KEY, null);
    }

    @SuppressLint("MissingPermission")
    void connect(String address) throws Exception {
        if (connected && gatt != null) return;
        if (!connecting.compareAndSet(false, true)) throw new IllegalStateException("Ya se está conectando con EKD01.");
        manualDisconnect = false;
        lastAddress = address;
        try {
            BluetoothManager manager = (BluetoothManager) context.getSystemService(Context.BLUETOOTH_SERVICE);
            BluetoothAdapter adapter = manager == null ? null : manager.getAdapter();
            if (adapter == null || !adapter.isEnabled()) throw new IllegalStateException("Activa Bluetooth e inténtalo de nuevo.");

            BluetoothDevice device;
            try {
                device = adapter.getRemoteDevice(address);
            } catch (IllegalArgumentException error) {
                throw new IllegalArgumentException("La dirección Bluetooth no es válida.");
            }

            readyLatch = new CountDownLatch(1);
            gatt = device.connectGatt(context, false, gattCallback, BluetoothDevice.TRANSPORT_LE);
            if (!readyLatch.await(20, TimeUnit.SECONDS)) {
                closeGatt();
                throw new IllegalStateException("No se pudo preparar el servicio BLE de EKD01.");
            }
            try {
                authenticate();
            } catch (Exception error) {
                closeGatt();
                throw error;
            }
            connected = true;
            reconnectAttempts = 0;
            context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE).edit().putString(ADDRESS_KEY, address).apply();
            startHeartbeat();
            EkdNavPlugin.emitConnectionState(true);
        } finally {
            connecting.set(false);
        }
    }

    @SuppressLint("MissingPermission")
    private final BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
        @Override
        public void onConnectionStateChange(BluetoothGatt currentGatt, int status, int newState) {
            if (newState == BluetoothProfile.STATE_CONNECTED && status == BluetoothGatt.GATT_SUCCESS) {
                gatt = currentGatt;
                currentGatt.discoverServices();
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                boolean shouldReconnect = connected && !manualDisconnect;
                connected = false;
                txCharacteristic = null;
                rxCharacteristic = null;
                currentGatt.close();
                if (gatt == currentGatt) gatt = null;
                EkdNavPlugin.emitConnectionState(false);
                if (shouldReconnect) scheduleReconnect();
            }
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt currentGatt, int status) {
            if (status != BluetoothGatt.GATT_SUCCESS) {
                readyLatch.countDown();
                return;
            }
            BluetoothGattService service = currentGatt.getService(SERVICE_UUID);
            if (service == null) {
                readyLatch.countDown();
                return;
            }
            txCharacteristic = service.getCharacteristic(TX_UUID);
            rxCharacteristic = service.getCharacteristic(RX_UUID);
            if (txCharacteristic == null || rxCharacteristic == null ||
                (txCharacteristic.getProperties() & BluetoothGattCharacteristic.PROPERTY_WRITE) == 0) {
                readyLatch.countDown();
                return;
            }
            currentGatt.setCharacteristicNotification(rxCharacteristic, true);
            BluetoothGattDescriptor descriptor = rxCharacteristic.getDescriptor(CCCD_UUID);
            if (descriptor == null) {
                readyLatch.countDown();
                return;
            }
            if (Build.VERSION.SDK_INT >= 33) {
                currentGatt.writeDescriptor(descriptor, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
            } else {
                descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                currentGatt.writeDescriptor(descriptor);
            }
        }

        @Override
        public void onDescriptorWrite(BluetoothGatt currentGatt, BluetoothGattDescriptor descriptor, int status) {
            if (readyLatch != null) readyLatch.countDown();
        }

        @Override
        public void onCharacteristicWrite(BluetoothGatt currentGatt, BluetoothGattCharacteristic characteristic, int status) {
            synchronized (EkdBleManager.this) {
                writeStatus = status;
                if (writeLatch != null) writeLatch.countDown();
            }
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt currentGatt, BluetoothGattCharacteristic characteristic) {
            handleNotification(characteristic.getValue());
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt currentGatt, BluetoothGattCharacteristic characteristic, byte[] value) {
            handleNotification(value);
        }
    };

    private void authenticate() throws Exception {
        byte[] challenge = sendAndWait(frame(0x10, 0x01, 0x00, new byte[] {0x04}), 0x10, 0x01, 0x00);
        byte[] plainText = new byte[16];
        System.arraycopy(challenge, 0, plainText, 0, Math.min(4, challenge.length));
        javax.crypto.Cipher cipher = javax.crypto.Cipher.getInstance("AES/ECB/NoPadding");
        cipher.init(javax.crypto.Cipher.ENCRYPT_MODE, new javax.crypto.spec.SecretKeySpec(AES_KEY, "AES"));
        byte[] response = cipher.doFinal(plainText);
        byte[] handshake = sendAndWait(frame(0x10, 0x20, 0x00, response), 0x10, 0x20, 0x00);
        if (handshake.length == 0 || handshake[0] != 0) throw new IllegalStateException("El EKD01 ha rechazado la autenticación.");

        long seconds = System.currentTimeMillis() / 1000L;
        byte[] timestamp = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt((int) seconds).array();
        write(frame(0x10, 0x02, 0x3E, timestamp));
    }

    private byte[] sendAndWait(byte[] frame, int command, int subcommand, int parameter) throws Exception {
        Exception lastError = null;
        for (int attempt = 0; attempt < 2; attempt++) {
            CompletableFuture<byte[]> response = new CompletableFuture<>();
            synchronized (this) {
                pendingResponse = new PendingResponse(command, subcommand, parameter, response);
            }
            try {
                write(frame);
                return response.get(2, TimeUnit.SECONDS);
            } catch (Exception error) {
                lastError = error;
            } finally {
                synchronized (this) {
                    if (pendingResponse != null && pendingResponse.response == response) pendingResponse = null;
                }
            }
        }
        throw new IllegalStateException("Tiempo de espera agotado durante la autenticación del EKD01.", lastError);
    }

    private void handleNotification(byte[] bytes) {
        if (bytes == null || bytes.length < 7) return;
        synchronized (this) {
            if (pendingResponse == null || bytes[0] != 0x55 || (bytes[1] & 0xff) != 0xaa) return;
            if ((bytes[3] & 0xff) != pendingResponse.command ||
                (bytes[6] & 0xff) != pendingResponse.parameter ||
                ((bytes[5] & 0xff) != pendingResponse.subcommand && (bytes[5] & 0xff) != 0x04)) return;
            int length = bytes[2] & 0xff;
            int start = 7;
            int end = Math.min(bytes.length, start + length);
            byte[] payload = new byte[Math.max(0, end - start)];
            System.arraycopy(bytes, start, payload, 0, payload.length);
            pendingResponse.response.complete(payload);
        }
    }

    void write(byte[] data) throws Exception {
        synchronized (writeMutex) {
            BluetoothGatt currentGatt = gatt;
            BluetoothGattCharacteristic characteristic = txCharacteristic;
            if (currentGatt == null || characteristic == null) throw new IllegalStateException("No hay una conexión BLE activa.");
            CountDownLatch latch = new CountDownLatch(1);
            synchronized (this) {
                writeLatch = latch;
                writeStatus = BluetoothGatt.GATT_FAILURE;
            }
            boolean accepted;
            if (Build.VERSION.SDK_INT >= 33) {
                accepted = currentGatt.writeCharacteristic(characteristic, data, BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT) == BluetoothGatt.GATT_SUCCESS;
            } else {
                characteristic.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
                characteristic.setValue(data);
                accepted = currentGatt.writeCharacteristic(characteristic);
            }
            if (!accepted || !latch.await(8, TimeUnit.SECONDS)) {
                synchronized (this) { writeLatch = null; }
                throw new IllegalStateException("Falló la escritura BLE.");
            }
            synchronized (this) {
                writeLatch = null;
                if (writeStatus != BluetoothGatt.GATT_SUCCESS) throw new IllegalStateException("Falló la escritura BLE.");
            }
        }
    }

    synchronized void startHeartbeat() {
        if (heartbeatTask != null) heartbeatTask.cancel(false);
        heartbeatTask = heartbeatExecutor.scheduleAtFixedRate(() -> {
            if (!connected) return;
            try {
                write(frame(0xA5, 0x01, 0xA4, new byte[] {0x01}));
            } catch (Exception error) {
                connected = false;
                EkdNavPlugin.emitConnectionState(false);
                closeGatt();
                scheduleReconnect();
            }
        }, 15, 15, TimeUnit.SECONDS);
    }

    private synchronized void scheduleReconnect() {
        if (manualDisconnect || lastAddress == null || reconnectAttempts >= 5) return;
        if (reconnectTask != null) reconnectTask.cancel(false);
        long delay = Math.min((1L << reconnectAttempts) * 1000L, 30000L);
        reconnectAttempts++;
        String address = lastAddress;
        reconnectTask = heartbeatExecutor.schedule(() -> {
            if (manualDisconnect || connected) return;
            try {
                connect(address);
            } catch (Exception error) {
                scheduleReconnect();
            }
        }, delay, TimeUnit.MILLISECONDS);
    }

    boolean isConnected() {
        return connected && gatt != null && txCharacteristic != null;
    }

    void reconnectSaved() {
        String address = lastAddress;
        if (connected || address == null) return;
        try {
            connect(address);
        } catch (Exception error) {
            scheduleReconnect();
        }
    }

    @SuppressLint("MissingPermission")
    synchronized void disconnect() {
        manualDisconnect = true;
        connected = false;
        lastAddress = null;
        context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE).edit().remove(ADDRESS_KEY).apply();
        if (reconnectTask != null) {
            reconnectTask.cancel(false);
            reconnectTask = null;
        }
        if (heartbeatTask != null) {
            heartbeatTask.cancel(false);
            heartbeatTask = null;
        }
        if (gatt != null) {
            gatt.disconnect();
            gatt.close();
            gatt = null;
        }
        txCharacteristic = null;
        rxCharacteristic = null;
        EkdNavPlugin.emitConnectionState(false);
    }

    private void closeGatt() {
        connected = false;
        if (gatt != null) {
            gatt.disconnect();
            gatt.close();
            gatt = null;
        }
    }

    private static byte[] frame(int target, int subcommand, int parameter, byte[] payload) {
        byte[] pre = new byte[9 + payload.length];
        pre[0] = 0x55;
        pre[1] = (byte) 0xaa;
        pre[2] = (byte) payload.length;
        pre[3] = 0x11;
        pre[4] = (byte) target;
        pre[5] = (byte) subcommand;
        pre[6] = (byte) parameter;
        System.arraycopy(payload, 0, pre, 7, payload.length);
        int sum = 0;
        for (int i = 0; i < pre.length - 2; i++) sum += pre[i] & 0xff;
        pre[pre.length - 2] = (byte) ((0xfe - (sum & 0xff)) & 0xff);
        pre[pre.length - 1] = (byte) ((0x100 - ((sum >> 8) & 0xff)) & 0xff);
        return pre;
    }

    private static final class PendingResponse {
        final int command;
        final int subcommand;
        final int parameter;
        final CompletableFuture<byte[]> response;

        PendingResponse(int command, int subcommand, int parameter, CompletableFuture<byte[]> response) {
            this.command = command;
            this.subcommand = subcommand;
            this.parameter = parameter;
            this.response = response;
        }
    }
}
