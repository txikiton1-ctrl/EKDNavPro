package com.ekdnavpro.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(android.os.Bundle savedInstanceState) {
        registerPlugin(EkdNavPlugin.class);
        super.onCreate(savedInstanceState);
    }
}
