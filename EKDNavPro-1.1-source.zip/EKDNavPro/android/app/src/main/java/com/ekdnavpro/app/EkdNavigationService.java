package com.ekdnavpro.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.speech.tts.TextToSpeech;
import android.util.Log;

import androidx.core.content.ContextCompat;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

public class EkdNavigationService extends Service implements LocationListener, TextToSpeech.OnInitListener {
    private static final String TAG = "EKDNavigation";
    private static final String CHANNEL_ID = "ekdnav_navigation";
    private static final int NOTIFICATION_ID = 101;
    private static final String EXTRA_ROUTE = "routeData";
    private static final String PREFS = "ekdnav_background_navigation";
    private static volatile EkdNavigationService current;

    private final ExecutorService navigationExecutor = Executors.newSingleThreadExecutor();
    private final ExecutorService rerouteExecutor = Executors.newSingleThreadExecutor();
    private final AtomicBoolean navigationWritePending = new AtomicBoolean();
    private final AtomicReference<byte[]> latestNavigationFrame = new AtomicReference<>();
    private final List<RoutePoint> points = new ArrayList<>();
    private final List<Turn> turns = new ArrayList<>();
    private LocationManager locationManager;
    private PowerManager.WakeLock wakeLock;
    private TextToSpeech textToSpeech;
    private volatile boolean running;
    private volatile boolean automaticRerouting;
    private volatile boolean rerouting;
    private volatile double progressMeters;
    private volatile int segmentIndex;
    private volatile long offRouteSince;
    private volatile long nextRerouteAt;
    private volatile Location lastLocation;
    private volatile String lastInstruction = "Navegación activa";
    private volatile String routeColor = "#2979ff";
    private volatile boolean hasDestination;
    private volatile boolean voiceEnabled = true;
    private volatile boolean textToSpeechReady;
    private volatile String pendingVoiceInfo;
    private String lastSpokenInstruction = "";
    private double[] routeDistances = new double[0];
    private volatile double destinationLat;
    private volatile double destinationLon;
    private volatile int routeVersion;
    private int sequence;
    private boolean explicitStop;

    public static void start(Context context, String routeData) {
        Intent intent = new Intent(context, EkdNavigationService.class);
        intent.putExtra(EXTRA_ROUTE, routeData);
        ContextCompat.startForegroundService(context, intent);
    }

    public static void stop(Context context) {
        EkdNavigationService service = current;
        if (service != null) service.explicitStop = true;
        context.stopService(new Intent(context, EkdNavigationService.class));
    }

    public static JSObject getStatus() {
        EkdNavigationService service = current;
        return service == null ? new JSObject() : service.createStatus();
    }

    @Override
    public void onCreate() {
        super.onCreate();
        current = this;
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        textToSpeech = new TextToSpeech(this, this);
        createNotificationChannel();
    }

    @Override
    public void onInit(int status) {
        if (status != TextToSpeech.SUCCESS) {
            Log.w(TAG, "Android text-to-speech is not available.");
            return;
        }
        int languageStatus = textToSpeech.setLanguage(new Locale("es", "ES"));
        textToSpeechReady = languageStatus != TextToSpeech.LANG_MISSING_DATA &&
            languageStatus != TextToSpeech.LANG_NOT_SUPPORTED;
        if (!textToSpeechReady) {
            Log.w(TAG, "Spanish text-to-speech data is not installed.");
            return;
        }
        if (voiceEnabled && pendingVoiceInfo != null) speakInstruction(pendingVoiceInfo);
    }

    public static EkdNavigationService getCurrent() {
        return current;
    }

    public void setVoiceEnabled(boolean enabled) {
        voiceEnabled = enabled;
        if (!enabled) {
            pendingVoiceInfo = null;
            lastSpokenInstruction = "";
            if (textToSpeech != null) textToSpeech.stop();
        } else if (pendingVoiceInfo != null) {
            speakInstruction(pendingVoiceInfo);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.hasExtra(EXTRA_ROUTE)) {
            String routeData = intent.getStringExtra(EXTRA_ROUTE);
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(EXTRA_ROUTE, routeData).apply();
            try {
                loadRoute(routeData);
            } catch (JSONException error) {
                Log.e(TAG, "Invalid route data", error);
                stopSelf();
                return START_NOT_STICKY;
            }
        } else if (points.size() < 2) {
            String savedRoute = getSharedPreferences(PREFS, MODE_PRIVATE).getString(EXTRA_ROUTE, null);
            if (savedRoute == null) {
                stopSelf();
                return START_NOT_STICKY;
            }
            try {
                loadRoute(savedRoute);
            } catch (JSONException error) {
                Log.e(TAG, "Could not restore route", error);
                stopSelf();
                return START_NOT_STICKY;
            }
        }

        startInForeground();
        if (!startLocationUpdates()) {
            running = false;
            return START_NOT_STICKY;
        }
        running = true;
        navigationExecutor.execute(() -> EkdBleManager.getInstance(this).reconnectSaved());
        return START_STICKY;
    }

    private void startInForeground() {
        Notification notification = buildNotification();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            int types = ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION;
            if (EkdBleManager.getInstance(this).isConnected()) {
                types |= ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE;
            }
            startForeground(NOTIFICATION_ID, notification, types);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
        PowerManager manager = (PowerManager) getSystemService(POWER_SERVICE);
        if (manager != null && (wakeLock == null || !wakeLock.isHeld())) {
            wakeLock = manager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "EKDNavPro:Navigation");
            wakeLock.acquire();
        }
    }

    private Notification buildNotification() {
        Intent openApp = getPackageManager().getLaunchIntentForPackage(getPackageName());
        PendingIntent pendingIntent = openApp == null ? null : PendingIntent.getActivity(
            this, 0, openApp, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            ? new Notification.Builder(this, CHANNEL_ID)
            : new Notification.Builder(this);
        builder.setContentTitle("EKDNavPro")
            .setContentText("Navegación GPS activa")
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setOngoing(true)
            .setCategory(Notification.CATEGORY_NAVIGATION);
        if (pendingIntent != null) builder.setContentIntent(pendingIntent);
        return builder.build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        NotificationChannel channel = new NotificationChannel(
            CHANNEL_ID, "Navegación", NotificationManager.IMPORTANCE_LOW
        );
        channel.setDescription("Mantiene activo el GPS y el enlace con EKD01 durante la navegación.");
        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager != null) manager.createNotificationChannel(channel);
    }

    private boolean startLocationUpdates() {
        if (!EkdNavPlugin.hasLocationPermission(this)) {
            EkdNavPlugin.emitNavigationEvent("navigationError", eventWithMessage("Falta el permiso de ubicación."));
            stopSelf();
            return false;
        }
        try {
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, this, Looper.getMainLooper());
            Location last = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (last != null) onLocationChanged(last);
            return true;
        } catch (SecurityException | IllegalArgumentException error) {
            EkdNavPlugin.emitNavigationEvent("navigationError", eventWithMessage("No se pudo iniciar el GPS: " + error.getMessage()));
            stopSelf();
            return false;
        }
    }

    private synchronized void loadRoute(String routeData) throws JSONException {
        JSONObject data = new JSONObject(routeData);
        JSONArray routePoints = data.getJSONArray("points");
        JSONArray routeTurns = data.getJSONArray("turns");
        if (routePoints.length() < 2) throw new JSONException("La ruta no tiene suficientes puntos.");

        points.clear();
        turns.clear();
        for (int i = 0; i < routePoints.length(); i++) {
            JSONObject point = routePoints.getJSONObject(i);
            points.add(new RoutePoint(point.getDouble("lat"), point.getDouble("lon"), point.optDouble("ele", Double.NaN)));
        }
        for (int i = 0; i < routeTurns.length(); i++) {
            JSONObject turn = routeTurns.getJSONObject(i);
            turns.add(new Turn(
                turn.optInt("index"),
                turn.getDouble("distFromStart"),
                turn.getInt("code"),
                turn.optString("label", "Continúa recto")
            ));
        }
        if (turns.isEmpty()) turns.add(new Turn(points.size() - 1, totalDistance(points), 10, "Has llegado a tu destino"));

        JSONObject destination = data.optJSONObject("destination");
        hasDestination = destination != null;
        automaticRerouting = data.optBoolean("automaticRerouting", false) && destination != null;
        routeColor = data.optString("routeColor", automaticRerouting ? "#2979ff" : "#00c853");
        voiceEnabled = data.optBoolean("voiceEnabled", true);
        if (destination != null) {
            destinationLat = destination.getDouble("lat");
            destinationLon = destination.getDouble("lon");
        }
        lastSpokenInstruction = "";
        pendingVoiceInfo = null;
        lastInstruction = "Navegación activa";
        progressMeters = 0;
        segmentIndex = 0;
        offRouteSince = 0;
        nextRerouteAt = 0;
        routeVersion++;
        rerouting = false;
        routeDistances = calculateRouteDistances(points);
        latestNavigationFrame.set(null);
    }

    @Override
    public void onLocationChanged(Location location) {
        if (!running || points.size() < 2) return;
        lastLocation = location;
        double offRouteDistance = updateProgress(location);
        NavigationFrame frame = navigationFrame(progressMeters);
        lastInstruction = frame.info;
        speakInstruction(frame.voiceInfo);
        publishLocation(location, offRouteDistance, frame);
        queueNavigationFrame(frame.bytes);
        checkOffRoute(location, offRouteDistance);
    }

    private void queueNavigationFrame(byte[] bytes) {
        latestNavigationFrame.set(bytes);
        scheduleNavigationWrite();
    }

    private void scheduleNavigationWrite() {
        if (!navigationWritePending.compareAndSet(false, true)) return;
        try {
            navigationExecutor.execute(() -> {
                EkdBleManager ble = EkdBleManager.getInstance(this);
                try {
                    byte[] nextFrame;
                    while ((nextFrame = latestNavigationFrame.getAndSet(null)) != null) {
                        if (!running) break;
                        if (!ble.isConnected()) continue;
                        try {
                            ble.write(nextFrame);
                        } catch (Exception error) {
                            Log.e(TAG, "Could not send navigation frame", error);
                            EkdNavPlugin.emitConnectionState(false);
                            break;
                        }
                    }
                } finally {
                    navigationWritePending.set(false);
                    if (latestNavigationFrame.get() != null) scheduleNavigationWrite();
                }
            });
        } catch (java.util.concurrent.RejectedExecutionException error) {
            navigationWritePending.set(false);
        }
    }

    private double updateProgress(Location location) {
        double latScale = 111320d;
        double lonScale = latScale * Math.cos(Math.toRadians(location.getLatitude()));
        double nearestDistance = Double.POSITIVE_INFINITY;
        double nearestProgress = progressMeters;
        int nearestIndex = segmentIndex;
        for (int i = Math.max(0, segmentIndex - 2); i < points.size() - 1; i++) {
            RoutePoint start = points.get(i);
            RoutePoint end = points.get(i + 1);
            double ax = (start.lon - location.getLongitude()) * lonScale;
            double ay = (start.lat - location.getLatitude()) * latScale;
            double bx = (end.lon - location.getLongitude()) * lonScale;
            double by = (end.lat - location.getLatitude()) * latScale;
            double dx = bx - ax;
            double dy = by - ay;
            double lengthSquared = dx * dx + dy * dy;
            double fraction = lengthSquared == 0 ? 0 : Math.max(0, Math.min(1, -(ax * dx + ay * dy) / lengthSquared));
            double distance = Math.hypot(ax + fraction * dx, ay + fraction * dy);
            if (distance < nearestDistance) {
                nearestDistance = distance;
                nearestProgress = routeDistances[i] + fraction * (routeDistances[i + 1] - routeDistances[i]);
                nearestIndex = i;
            }
        }
        if (nearestDistance <= routeTolerance(location)) {
            progressMeters = Math.max(progressMeters, nearestProgress);
            segmentIndex = Math.max(segmentIndex, nearestIndex);
        }
        return nearestDistance;
    }

    private static double routeTolerance(Location location) {
        return location.hasAccuracy() ? Math.max(50d, Math.min(location.getAccuracy(), 100d)) : 50d;
    }

    private NavigationFrame navigationFrame(double distance) {
        double total = turns.isEmpty() ? (routeDistances.length == 0 ? 0 : routeDistances[routeDistances.length - 1]) : turns.get(turns.size() - 1).distance;
        double remaining = Math.max(0, total - distance);
        List<Turn> upcoming = new ArrayList<>();
        for (Turn turn : turns) if (turn.distance > distance) upcoming.add(turn);
        if (upcoming.isEmpty() || remaining < 25) {
            byte[] arrived = encodeNav(0, 10, 0, 0, 0, 0, 0);
            return new NavigationFrame(arrived, "¡Has llegado a tu destino!", "¡Has llegado a tu destino!", 0);
        }
        Turn first = upcoming.get(0);
        Turn next = upcoming.size() > 1 ? upcoming.get(1) : new Turn(points.size() - 1, total, 10, "Destino");
        int distanceToTurn = Math.max(0, (int) (first.distance - distance));
        int distanceToNext = Math.max(0, (int) (next.distance - first.distance));
        byte[] bytes = encodeNav(distanceToTurn, first.code, distanceToNext, next.code, 0, 0, (int) remaining);
        String info = String.format(Locale.getDefault(), "En %d metros, %s | Total: %.1f km", distanceToTurn, first.label, remaining / 1000d);
        String voiceInfo = String.format(Locale.getDefault(), "En %d metros, %s", (int) (Math.ceil(distanceToTurn / 50d) * 50), first.label);
        return new NavigationFrame(bytes, info, voiceInfo, remaining);
    }

    private void speakInstruction(String instruction) {
        if (!voiceEnabled || instruction == null || instruction.isEmpty() || instruction.equals(lastSpokenInstruction)) return;
        pendingVoiceInfo = instruction;
        if (!textToSpeechReady || textToSpeech == null) return;
        pendingVoiceInfo = null;
        lastSpokenInstruction = instruction;
        textToSpeech.speak(instruction, TextToSpeech.QUEUE_FLUSH, null, "ekdnav-instruction");
    }

    private byte[] encodeNav(int currentDistance, int currentManeuver, int nextDistance, int nextManeuver,
                             int nextNextDistance, int nextNextManeuver, int totalDistance) {
        byte[] payload = new byte[] {
            (byte) (sequence++ & 0xff), 0x02,
            (byte) currentDistance, (byte) (currentDistance >> 8), (byte) (currentDistance >> 16), (byte) currentManeuver,
            (byte) nextDistance, (byte) (nextDistance >> 8), (byte) (nextDistance >> 16), (byte) nextManeuver,
            (byte) nextNextDistance, (byte) (nextNextDistance >> 8), (byte) (nextNextDistance >> 16), (byte) nextNextManeuver,
            (byte) totalDistance, (byte) (totalDistance >> 8), (byte) (totalDistance >> 16), (byte) (totalDistance >> 24)
        };
        return makeFrame(0xf1, 0x03, 0x00, payload);
    }

    private void checkOffRoute(Location location, double distance) {
        if (!automaticRerouting || rerouting || System.currentTimeMillis() < nextRerouteAt) {
            offRouteSince = 0;
            return;
        }
        if (distance <= routeTolerance(location)) {
            offRouteSince = 0;
            return;
        }
        long now = System.currentTimeMillis();
        if (offRouteSince == 0) {
            offRouteSince = now;
            return;
        }
        if (now - offRouteSince >= 5000) {
            offRouteSince = 0;
            rerouting = true;
            Location snapshot = new Location(location);
            int expectedVersion = routeVersion;
            rerouteExecutor.execute(() -> requestNewRoute(snapshot, expectedVersion));
        }
    }

    private void requestNewRoute(Location location, int expectedVersion) {
        HttpURLConnection connection = null;
        try {
            double targetLat = destinationLat;
            double targetLon = destinationLon;
            String lonlats = location.getLongitude() + "," + location.getLatitude() + "|" + targetLon + "," + targetLat;
            String query = "lonlats=" + URLEncoder.encode(lonlats, "UTF-8") +
                "&profile=fastbike&alternativeidx=0&format=geojson";
            connection = (HttpURLConnection) new URL("https://brouter.de/brouter?" + query).openConnection();
            connection.setConnectTimeout(12000);
            connection.setReadTimeout(20000);
            connection.setRequestProperty("Accept", "application/geo+json, application/json");
            int status = connection.getResponseCode();
            if (status < 200 || status >= 300) throw new IllegalStateException("El servicio MTB respondió " + status + ".");
            StringBuilder body = new StringBuilder();
            try (InputStream input = connection.getInputStream();
                 BufferedReader reader = new BufferedReader(new InputStreamReader(input, StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) body.append(line);
            }
            JSONObject response = new JSONObject(body.toString());
            JSONArray features = response.optJSONArray("features");
            JSONArray coordinates = features == null || features.length() == 0
                ? null : features.getJSONObject(0).getJSONObject("geometry").optJSONArray("coordinates");
            if (coordinates == null || coordinates.length() < 2) throw new IllegalStateException("No se encontró una ruta nueva.");
            List<RoutePoint> newPoints = new ArrayList<>();
            for (int i = 0; i < coordinates.length(); i++) {
                JSONArray coordinate = coordinates.getJSONArray(i);
                newPoints.add(new RoutePoint(coordinate.getDouble(1), coordinate.getDouble(0),
                    coordinate.length() > 2 ? coordinate.getDouble(2) : Double.NaN));
            }
            List<Turn> newTurns = detectTurns(newPoints);
            new android.os.Handler(Looper.getMainLooper()).post(() -> {
                synchronized (EkdNavigationService.this) {
                    if (expectedVersion != routeVersion) return;
                    points.clear();
                    points.addAll(newPoints);
                    turns.clear();
                    turns.addAll(newTurns);
                    routeDistances = calculateRouteDistances(points);
                    progressMeters = 0;
                    segmentIndex = 0;
                    routeVersion++;
                    rerouting = false;
                }
                publishRoute();
            });
        } catch (Exception error) {
            Log.e(TAG, "Automatic route recalculation failed", error);
            if (expectedVersion == routeVersion) {
                rerouting = false;
                nextRerouteAt = System.currentTimeMillis() + 30000;
                EkdNavPlugin.emitNavigationEvent("rerouteError", eventWithMessage(error.getMessage() == null ? "No se pudo recalcular la ruta." : error.getMessage()));
            }
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private List<Turn> detectTurns(List<RoutePoint> route) {
        List<Turn> result = new ArrayList<>();
        double accumulated = 0;
        for (int i = 1; i < route.size() - 1; i++) {
            accumulated += haversine(route.get(i - 1), route.get(i));
            double firstBearing = bearing(route.get(i - 1), route.get(i));
            double secondBearing = bearing(route.get(i), route.get(i + 1));
            double difference = secondBearing - firstBearing;
            while (difference > 180) difference -= 360;
            while (difference < -180) difference += 360;
            if (Math.abs(difference) >= 45) {
                int code = difference > 0 ? 3 : 2;
                String label = difference > 0 ? "Gira a la derecha" : "Gira a la izquierda";
                Turn previous = result.isEmpty() ? null : result.get(result.size() - 1);
                if (previous == null || accumulated - previous.distance > 40) {
                    result.add(new Turn(i, Math.round(accumulated), code, label));
                }
            }
        }
        double total = accumulated + haversine(route.get(route.size() - 2), route.get(route.size() - 1));
        result.add(new Turn(route.size() - 1, Math.round(total), 10, "Has llegado a tu destino"));
        return result;
    }

    private void publishLocation(Location location, double offRouteDistance, NavigationFrame frame) {
        JSObject data = new JSObject();
        data.put("latitude", location.getLatitude());
        data.put("longitude", location.getLongitude());
        data.put("speedKmh", location.hasSpeed() ? location.getSpeed() * 3.6 : 0);
        data.put("progressMeters", progressMeters);
        data.put("offRouteMeters", offRouteDistance);
        data.put("remainingMeters", frame.remainingMeters);
        data.put("info", frame.info);
        data.put("voiceInfo", frame.voiceInfo);
        data.put("running", running);
        EkdNavPlugin.emitNavigationEvent("navigationUpdate", data);
    }

    private void publishRoute() {
        JSObject data = new JSObject();
        JSArray routePoints = new JSArray();
        JSArray routeTurns = new JSArray();
        for (RoutePoint point : points) {
            JSObject value = new JSObject();
            value.put("lat", point.lat);
            value.put("lon", point.lon);
            if (Double.isFinite(point.ele)) value.put("ele", point.ele);
            routePoints.put(value);
        }
        for (Turn turn : turns) {
            JSObject value = new JSObject();
            value.put("index", turn.index);
            value.put("distFromStart", turn.distance);
            value.put("code", turn.code);
            value.put("label", turn.label);
            routeTurns.put(value);
        }
        data.put("points", routePoints);
        data.put("turns", routeTurns);
        data.put("progressMeters", progressMeters);
        data.put("routeColor", routeColor);
        EkdNavPlugin.emitNavigationEvent("routeUpdated", data);
    }

    private synchronized JSObject createStatus() {
        JSObject data = new JSObject();
        JSArray routePoints = new JSArray();
        JSArray routeTurns = new JSArray();
        for (RoutePoint point : points) {
            JSObject value = new JSObject();
            value.put("lat", point.lat);
            value.put("lon", point.lon);
            if (Double.isFinite(point.ele)) value.put("ele", point.ele);
            routePoints.put(value);
        }
        for (Turn turn : turns) {
            JSObject value = new JSObject();
            value.put("index", turn.index);
            value.put("distFromStart", turn.distance);
            value.put("code", turn.code);
            value.put("label", turn.label);
            routeTurns.put(value);
        }
        data.put("running", running);
        data.put("points", routePoints);
        data.put("turns", routeTurns);
        data.put("progressMeters", progressMeters);
        data.put("info", lastInstruction);
        if (hasDestination) {
            JSObject destination = new JSObject();
            destination.put("lat", destinationLat);
            destination.put("lon", destinationLon);
            data.put("destination", destination);
        }
        data.put("automaticRerouting", automaticRerouting);
        data.put("voiceEnabled", voiceEnabled);
        data.put("routeColor", routeColor);
        if (lastLocation != null) {
            data.put("latitude", lastLocation.getLatitude());
            data.put("longitude", lastLocation.getLongitude());
            data.put("speedKmh", lastLocation.hasSpeed() ? lastLocation.getSpeed() * 3.6 : 0);
        }
        return data;
    }

    private static JSObject eventWithMessage(String message) {
        JSObject value = new JSObject();
        value.put("message", message);
        return value;
    }

    private static byte[] makeFrame(int target, int subcommand, int parameter, byte[] payload) {
        byte[] frame = new byte[9 + payload.length];
        frame[0] = 0x55;
        frame[1] = (byte) 0xaa;
        frame[2] = (byte) payload.length;
        frame[3] = 0x11;
        frame[4] = (byte) target;
        frame[5] = (byte) subcommand;
        frame[6] = (byte) parameter;
        System.arraycopy(payload, 0, frame, 7, payload.length);
        int sum = 0;
        for (int i = 0; i < frame.length - 2; i++) sum += frame[i] & 0xff;
        frame[frame.length - 2] = (byte) ((0xfe - (sum & 0xff)) & 0xff);
        frame[frame.length - 1] = (byte) ((0x100 - ((sum >> 8) & 0xff)) & 0xff);
        return frame;
    }

    private static double[] calculateRouteDistances(List<RoutePoint> route) {
        double[] distances = new double[route.size()];
        for (int i = 1; i < route.size(); i++) distances[i] = distances[i - 1] + haversine(route.get(i - 1), route.get(i));
        return distances;
    }

    private static double totalDistance(List<RoutePoint> route) {
        double total = 0;
        for (int i = 1; i < route.size(); i++) total += haversine(route.get(i - 1), route.get(i));
        return total;
    }

    private static double haversine(RoutePoint first, RoutePoint second) {
        double lat1 = Math.toRadians(first.lat);
        double lat2 = Math.toRadians(second.lat);
        double deltaLat = Math.toRadians(second.lat - first.lat);
        double deltaLon = Math.toRadians(second.lon - first.lon);
        double a = Math.sin(deltaLat / 2) * Math.sin(deltaLat / 2) +
            Math.cos(lat1) * Math.cos(lat2) * Math.sin(deltaLon / 2) * Math.sin(deltaLon / 2);
        return 6371000d * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    }

    private static double bearing(RoutePoint first, RoutePoint second) {
        double lat1 = Math.toRadians(first.lat);
        double lat2 = Math.toRadians(second.lat);
        double deltaLon = Math.toRadians(second.lon - first.lon);
        double y = Math.sin(deltaLon) * Math.cos(lat2);
        double x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(deltaLon);
        return (Math.toDegrees(Math.atan2(y, x)) + 360) % 360;
    }

    @Override
    public void onProviderEnabled(String provider) {}

    @Override
    public void onProviderDisabled(String provider) {
        EkdNavPlugin.emitNavigationEvent("navigationError", eventWithMessage("El GPS está desactivado."));
    }

    @Override
    public void onStatusChanged(String provider, int status, android.os.Bundle extras) {}

    @Override
    public void onDestroy() {
        running = false;
        if (locationManager != null) locationManager.removeUpdates(this);
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
        }
        if (explicitStop) {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove(EXTRA_ROUTE).apply();
            try {
                EkdBleManager.getInstance(this).write(makeFrame(0xf1, 0x02, 0x02, new byte[] {0x00}));
            } catch (Exception error) {
                Log.w(TAG, "Could not send navigation stop frame", error);
            }
        }
        navigationExecutor.shutdownNow();
        rerouteExecutor.shutdownNow();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) stopForeground(STOP_FOREGROUND_REMOVE);
        else stopForeground(true);
        if (current == this) current = null;
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private static final class RoutePoint {
        final double lat;
        final double lon;
        final double ele;

        RoutePoint(double lat, double lon, double ele) {
            this.lat = lat;
            this.lon = lon;
            this.ele = ele;
        }
    }

    private static final class Turn {
        final int index;
        final double distance;
        final int code;
        final String label;

        Turn(int index, double distance, int code, String label) {
            this.index = index;
            this.distance = distance;
            this.code = code;
            this.label = label;
        }
    }

    private static final class NavigationFrame {
        final byte[] bytes;
        final String info;
        final String voiceInfo;
        final double remainingMeters;

        NavigationFrame(byte[] bytes, String info, String voiceInfo, double remainingMeters) {
            this.bytes = bytes;
            this.info = info;
            this.voiceInfo = voiceInfo;
            this.remainingMeters = remainingMeters;
        }
    }
}
