import { Capacitor, registerPlugin } from '@capacitor/core';

export const EkdNav = registerPlugin('EkdNav');
export const isNativeAndroid = Capacitor.getPlatform() === 'android';
