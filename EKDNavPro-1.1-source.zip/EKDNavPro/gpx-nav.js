export class GpxNavigator {
  constructor(protocol) {
    this.protocol = protocol;
    this.points = [];
    this.turns = [];
  }

  loadGpxText(xmlText) {
    const parser = new DOMParser();
    const xml = parser.parseFromString(xmlText, 'text/xml');
    let ptsNodes = Array.from(xml.querySelectorAll('trkpt'));
    const routePoints = Array.from(xml.querySelectorAll('rtept'));
    const usesRoutePoints = ptsNodes.length < 2;
    if (usesRoutePoints) ptsNodes = routePoints;
    if (ptsNodes.length < 2) throw new Error('GPX sin puntos suficientes.');

    this.points = ptsNodes.map(pt => {
      const elevation = parseFloat(pt.querySelector('ele')?.textContent);
      return {
        lat: parseFloat(pt.getAttribute('lat')),
        lon: parseFloat(pt.getAttribute('lon')),
        ele: Number.isFinite(elevation) ? elevation : null
      };
    });

    const wpts = Array.from(xml.querySelectorAll('wpt'));
    this.turns = [];
    if (wpts.length > 0) this.extractWaypoints(wpts);
    if (routePoints.length > 0) this.extractWaypoints(routePoints);
    if (this.turns.length === 0) this.detectTurns();
    else {
      this.turns = this.turns.filter((turn, index, turns) =>
        index === 0 || turn.distFromStart !== turns[index - 1].distFromStart || turn.code !== turns[index - 1].code
      );
      const lastTurn = this.turns.at(-1);
      const totalDistance = this.points.slice(1).reduce((distance, point, index) =>
        distance + this.haversine(this.points[index], point), 0);
      if (lastTurn.code !== this.protocol.MANEUVER.ARRIVE || lastTurn.distFromStart < Math.round(totalDistance)) {
        this.turns.push({
          index: this.points.length - 1,
          distFromStart: Math.round(totalDistance),
          code: this.protocol.MANEUVER.ARRIVE,
          label: 'Destino alcanzado'
        });
      }
    }

    return { points: this.points, turns: this.turns };
  }

  extractWaypoints(wpts) {
    let accDist = 0;
    const dists = [0];
    for (let i = 1; i < this.points.length; i++) {
      accDist += this.haversine(this.points[i - 1], this.points[i]);
      dists.push(Math.round(accDist));
    }

    wpts.forEach(wpt => {
      const wLat = parseFloat(wpt.getAttribute('lat'));
      const wLon = parseFloat(wpt.getAttribute('lon'));
      const rawText = (wpt.querySelector('name')?.textContent || wpt.querySelector('desc')?.textContent || '').trim();
      if (!rawText) return;

      let minD = Infinity, closestIdx = 0;
      this.points.forEach((p, idx) => {
        const d = this.haversine({ lat: wLat, lon: wLon }, p);
        if (d < minD) { minD = d; closestIdx = idx; }
      });

      if (minD < 30) {
        const { code, label } = this.parseInstruction(rawText);
        if (code === null) return;
        this.turns.push({ index: closestIdx, distFromStart: dists[closestIdx], code, label });
      }
    });

    this.turns.sort((a, b) => a.distFromStart - b.distFromStart);
  }

  parseInstruction(text) {
    const t = text.toLowerCase();
    if (t.includes('u-turn') || t.includes('u turn') || t.includes('uturn') || t.includes('cambio de sentido')) {
      return { code: this.protocol.MANEUVER.UTURN, label: 'Haz un cambio de sentido' };
    }
    if (t.includes('sharp left') || t.includes('cerrada izquierda')) return { code: this.protocol.MANEUVER.SHARP_LEFT, label: 'Giro cerrado a la izquierda' };
    if (t.includes('slight left') || t.includes('ligera izquierda')) return { code: this.protocol.MANEUVER.SLIGHT_LEFT, label: 'Gira ligeramente a la izquierda' };
    if (t.includes('left') || t.includes('izquierda')) return { code: this.protocol.MANEUVER.LEFT, label: 'Gira a la izquierda' };
    if (t.includes('sharp right') || t.includes('cerrada derecha')) return { code: this.protocol.MANEUVER.SHARP_RIGHT, label: 'Giro cerrado a la derecha' };
    if (t.includes('slight right') || t.includes('ligera derecha')) return { code: this.protocol.MANEUVER.SLIGHT_RIGHT, label: 'Gira ligeramente a la derecha' };
    if (t.includes('right') || t.includes('derecha')) return { code: this.protocol.MANEUVER.RIGHT, label: 'Gira a la derecha' };
    if (t.includes('arrive') || t.includes('destination') || t.includes('llegada') || t.includes('destino')) {
      return { code: this.protocol.MANEUVER.ARRIVE, label: 'Has llegado a tu destino' };
    }
    if (t.includes('straight') || t.includes('continue') || t.includes('continua') || t.includes('sigue recto')) {
      return { code: this.protocol.MANEUVER.STRAIGHT, label: 'Continúa recto' };
    }
    return { code: null, label: '' };
  }

  detectTurns() {
    this.turns = [];
    let accDist = 0;
    for (let i = 1; i < this.points.length - 1; i++) {
      accDist += this.haversine(this.points[i - 1], this.points[i]);
      const b1 = this.bearing(this.points[i - 1], this.points[i]);
      const b2 = this.bearing(this.points[i], this.points[i + 1]);
      let diff = b2 - b1;
      while (diff > 180) diff -= 360;
      while (diff < -180) diff += 360;

      if (Math.abs(diff) >= 45) {
        const code = diff > 0 ? this.protocol.MANEUVER.RIGHT : this.protocol.MANEUVER.LEFT;
        const label = diff > 0 ? 'Gira a la derecha' : 'Gira a la izquierda';
        const last = this.turns.at(-1);
        if (!last || (accDist - last.distFromStart) > 40) {
          this.turns.push({ index: i, distFromStart: Math.round(accDist), code, label });
        }
      }
    }
    const total = Math.round(accDist + this.haversine(this.points.at(-2), this.points.at(-1)));
    this.turns.push({ index: this.points.length - 1, distFromStart: total, code: this.protocol.MANEUVER.ARRIVE, label: 'Has llegado a tu destino' });
  }

  getNavFrameForDistance(currentDistMeters) {
    const upcoming = this.turns.filter(t => t.distFromStart > currentDistMeters);
    const totalDist = this.turns.at(-1)?.distFromStart || 0;
    const remaining = Math.max(0, totalDist - currentDistMeters);

    if (upcoming.length === 0 || remaining < 25) {
      return {
        frame: this.protocol.encodeNav(0, this.protocol.MANEUVER.ARRIVE, 0, 0, 0, 0, 0),
        info: '¡Has llegado a tu destino!',
        voiceInfo: '¡Has llegado a tu destino!'
      };
    }

    const t1 = upcoming[0];
    const d1 = Math.max(0, t1.distFromStart - currentDistMeters);
    const t2 = upcoming[1] || { distFromStart: totalDist, code: this.protocol.MANEUVER.ARRIVE, label: 'Destino' };
    const d2 = Math.max(0, t2.distFromStart - t1.distFromStart);

    return {
      frame: this.protocol.encodeNav(d1, t1.code, d2, t2.code, 0, 0, remaining),
      info: `En ${Math.round(d1)} metros, ${t1.label} | Total: ${(remaining / 1000).toFixed(1)} km`,
      voiceInfo: `En ${Math.ceil(d1 / 50) * 50} metros, ${t1.label}`
    };
  }

  haversine(p1, p2) {
    const R = 6371000, toRad = d => d * Math.PI / 180;
    const dLat = toRad(p2.lat - p1.lat), dLon = toRad(p2.lon - p1.lon);
    const a = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(p1.lat)) * Math.cos(toRad(p2.lat)) * Math.sin(dLon / 2) ** 2;
    return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  }

  bearing(p1, p2) {
    const toRad = d => d * Math.PI / 180, toDeg = r => r * 180 / Math.PI;
    const y = Math.sin(toRad(p2.lon - p1.lon)) * Math.cos(toRad(p2.lat));
    const x = Math.cos(toRad(p1.lat)) * Math.sin(toRad(p2.lat)) - Math.sin(toRad(p1.lat)) * Math.cos(toRad(p2.lat)) * Math.cos(toRad(p2.lon - p1.lon));
    return (toDeg(Math.atan2(y, x)) + 360) % 360;
  }
}
