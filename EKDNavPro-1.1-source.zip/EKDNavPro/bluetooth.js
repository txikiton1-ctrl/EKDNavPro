import { EkdNav, isNativeAndroid } from './native-bridge.js';

const NUS_SERVICE = '6e400001-b5a3-f393-e0a9-e50e24dcca9e';
const NUS_TX = '6e400002-b5a3-f393-e0a9-e50e24dcca9e';
const NUS_RX = '6e400003-b5a3-f393-e0a9-e50e24dcca9e';
const DEVICE_PREFIX = 'EKD01';

export const ConnectionStatus = {
  DISCONNECTED: 'disconnected',
  CONNECTING: 'connecting',
  CONNECTED: 'connected',
  RECONNECTING: 'reconnecting',
};

export class BluetoothManager extends EventTarget {
  constructor() {
    super();
    this.device = null;
    this.server = null;
    this.service = null;
    this.txChar = null;
    this.rxChar = null;
    this.writeQueue = Promise.resolve();
    this._connected = false;
    this.listeners = {};
    this.reconnectAttempts = 0;
    this.reconnectTimer = null;
    this._heartbeatTimer = null;
    this._disconnectHandler = null;
    this._manualDisconnect = false;
    this._reconnecting = false;
    this._rxHandler = null;
    this.protocol = null;
    this._status = ConnectionStatus.DISCONNECTED;
    this.nativeMode = isNativeAndroid;

    if (this.nativeMode) {
      EkdNav.addListener('connectionState', ({ connected }) => {
        this.connected = connected;
        this._setStatus(connected ? ConnectionStatus.CONNECTED : ConnectionStatus.DISCONNECTED);
        if (!connected) this.emit('disconnected');
      }).catch(error => console.error('No se pudo escuchar el estado BLE nativo:', error));
    }
  }

  get connected() { return this._connected; }
  set connected(v) { this._connected = v; }
  get status() { return this._status; }

  _setStatus(status) {
    if (this._status === status) return;
    this._status = status;
    this.dispatchEvent(new CustomEvent('statuschange', { detail: { status } }));
  }

  on(event, fn) { (this.listeners[event] ||= []).push(fn); }
  off(event, fn) { const arr = this.listeners[event]; if (arr) { const i = arr.indexOf(fn); if (i !== -1) arr.splice(i, 1); } }
  emit(event, ...args) { (this.listeners[event] || []).forEach(fn => { try { fn(...args); } catch (_) {} }); }

  async requestDevice() {
    if (this.nativeMode) throw new Error('Introduce la dirección Bluetooth del EKD01 para conectarlo.');
    if (!navigator.bluetooth) throw new Error('Web Bluetooth no disponible en este navegador');
    if (!window.isSecureContext) throw new Error('Bluetooth requiere HTTPS o localhost');
    this.device = await navigator.bluetooth.requestDevice({
      filters: [{ namePrefix: DEVICE_PREFIX }],
      optionalServices: [NUS_SERVICE],
    });
    return this.device;
  }

  async connect() {
    if (this.nativeMode) throw new Error('Usa connectNative para conectar el EKD01 en Android.');
    this._setStatus(ConnectionStatus.CONNECTING);
    if (!this.device) throw new Error('Ningún dispositivo seleccionado');
    try {
      this.server = await this.device.gatt.connect();
      this.service = await this.server.getPrimaryService(NUS_SERVICE);
      this.txChar = await this.service.getCharacteristic(NUS_TX);
      this.rxChar = await this.service.getCharacteristic(NUS_RX);

      if (!this.txChar.properties.write) {
        throw new Error('La característica TX de EKD01 no admite escrituras con respuesta');
      }

      await this.rxChar.startNotifications();
      if (this._rxHandler) this.rxChar.removeEventListener('characteristicvaluechanged', this._rxHandler);
      this._rxHandler = (e) => {
        const value = e.target.value;
        const bytes = new Uint8Array(value.buffer, value.byteOffset, value.byteLength);
        this.emit('display-data', bytes);
      };
      this.rxChar.addEventListener('characteristicvaluechanged', this._rxHandler);
    } catch (error) {
      this.connected = false;
      this._setStatus(ConnectionStatus.DISCONNECTED);
      if (this.device?.gatt?.connected) this.device.gatt.disconnect();
      this.server = null;
      this.service = null;
      this.txChar = null;
      this.rxChar = null;
      throw new Error(`No se pudo preparar el servicio BLE de EKD01: ${error.message}`);
    }

    this.stopReconnectBackoff();
    localStorage.setItem('ekdnav_device_name', this.device.name || '');
    if (this.device.id) localStorage.setItem('ekdnav_device_id', this.device.id);

    if (this._disconnectHandler) this.device.removeEventListener('gattserverdisconnected', this._disconnectHandler);
    this._disconnectHandler = () => {
      this.connected = false;
      this._setStatus(ConnectionStatus.DISCONNECTED);
      this.emit('disconnected');
      this.stopHeartbeat();
      if (this._manualDisconnect) { this._manualDisconnect = false; return; }
      this.startReconnectBackoff();
    };
    this.device.addEventListener('gattserverdisconnected', this._disconnectHandler);

    await new Promise(r => setTimeout(r, 500));
    this.connected = true;
    this.reconnectAttempts = 0;
    this._setStatus(ConnectionStatus.CONNECTED);
    this.emit('connected');
    return this;
  }

  async connectNative(address) {
    if (!this.nativeMode) throw new Error('La conexión BLE nativa solo está disponible en Android.');
    this._setStatus(ConnectionStatus.CONNECTING);
    try {
      await EkdNav.connect({ address: address.trim().toUpperCase() });
      this.connected = true;
      this._setStatus(ConnectionStatus.CONNECTED);
      this.emit('connected');
      return this;
    } catch (error) {
      this.connected = false;
      this._setStatus(ConnectionStatus.DISCONNECTED);
      throw error;
    }
  }

  async reconnect() {
    this._setStatus(ConnectionStatus.RECONNECTING);
    if (!navigator.bluetooth.getDevices) throw new Error('Reconexión no soportada');
    const devices = await navigator.bluetooth.getDevices();
    const storedId = localStorage.getItem('ekdnav_device_id');
    const dev = storedId ? devices.find(d => d.id === storedId) : devices.find(d => d.name && d.name.startsWith(DEVICE_PREFIX));
    if (!dev) throw new Error('Dispositivo previo no encontrado');
    this.device = dev;
    return this.connect();
  }

  startReconnectBackoff() {
    this._setStatus(ConnectionStatus.RECONNECTING);
    this.stopReconnectBackoff();
    this.reconnectAttempts++;
    if (this.reconnectAttempts > 5) return;
    const delay = Math.min(Math.pow(2, this.reconnectAttempts - 1) * 1000, 30000);
    this.reconnectTimer = setTimeout(async () => {
      if (this._reconnecting) return;
      this._reconnecting = true;
      try { await this.reconnect(); } catch { this.startReconnectBackoff(); } finally { this._reconnecting = false; }
    }, delay);
  }

  stopReconnectBackoff() {
    if (this.reconnectTimer) { clearTimeout(this.reconnectTimer); this.reconnectTimer = null; }
  }

  startHeartbeat(intervalMs) {
    this.stopHeartbeat();
    if (this.nativeMode) return;
    if (!this.connected) return;
    this._heartbeatTimer = setInterval(() => {
      if (!this.protocol) return;
      const frame = this.protocol.encodeSettingsRead(0xA5, 0xA4, 1);
      this.write(frame).catch(err => console.error('Error en heartbeat BLE:', err));
    }, intervalMs);
  }

  stopHeartbeat() {
    if (this._heartbeatTimer) { clearInterval(this._heartbeatTimer); this._heartbeatTimer = null; }
  }

  async write(data) {
    if (this.nativeMode) {
      if (!this.connected) throw new Error('No hay una conexión BLE activa para enviar datos');
      await EkdNav.write({ data: Array.from(data) });
      return { ok: true };
    }
    if (!this.txChar || this._status !== ConnectionStatus.CONNECTED) {
      throw new Error('No hay una conexión BLE activa para enviar datos');
    }
    const writeResult = this.writeQueue.then(async () => {
      try {
        await this.txChar.writeValueWithResponse(data);
        return { ok: true };
      } catch (err) {
        this.connected = false;
        this._setStatus(ConnectionStatus.DISCONNECTED);
        throw new Error(`Falló la escritura BLE: ${err.message}`);
      }
    });
    this.writeQueue = writeResult.catch(() => {});
    return writeResult;
  }

  async disconnect() {
    if (this.nativeMode) {
      await EkdNav.disconnect();
      this.connected = false;
      this._setStatus(ConnectionStatus.DISCONNECTED);
      return;
    }
    this._manualDisconnect = true;
    this._setStatus(ConnectionStatus.DISCONNECTED);
    this.stopHeartbeat();
    this.stopReconnectBackoff();
    if (this.device && this.device.gatt.connected) this.device.gatt.disconnect();
    this.connected = false;
  }
}
