export class Protocol {
  constructor() { this.seq = 0; }
  SYNC = [0x55, 0xAA];

  calcChecksums(bytes) {
    let sum = 0;
    for (const b of bytes) sum += b;
    return [(0xFE - (sum & 0xFF)) & 0xFF, (0x100 - ((sum >> 8) & 0xFF)) & 0xFF];
  }

  frame(target, sub, param, payload) {
    const p = payload || [];
    const pre = new Uint8Array([this.SYNC[0], this.SYNC[1], p.length, 0x11, target, sub, param, ...p]);
    const [cs1, cs2] = this.calcChecksums(pre);
    const buf = new Uint8Array(pre.length + 2);
    buf.set(pre, 0);
    buf[pre.length] = cs1;
    buf[pre.length + 1] = cs2;
    return buf;
  }

  MANEUVER = { STRAIGHT: 1, LEFT: 2, RIGHT: 3, SLIGHT_LEFT: 4, SLIGHT_RIGHT: 5, SHARP_LEFT: 6, SHARP_RIGHT: 7, UTURN: 8, ARRIVE: 10 };

  encodeNav(currentDist, currentManeuver, nextDist, nextManeuver, nnextDist, nnextManeuver, totalDist) {
    const payload = [
      this.seq++, 0x02,
      currentDist & 0xFF, (currentDist >> 8) & 0xFF, (currentDist >> 16) & 0xFF, currentManeuver,
      nextDist & 0xFF, (nextDist >> 8) & 0xFF, (nextDist >> 16) & 0xFF, nextManeuver,
      nnextDist & 0xFF, (nnextDist >> 8) & 0xFF, (nnextDist >> 16) & 0xFF, nnextManeuver,
      totalDist & 0xFF, (totalDist >> 8) & 0xFF, (totalDist >> 16) & 0xFF, (totalDist >> 24) & 0xFF,
    ];
    return this.frame(0xF1, 0x03, 0x00, payload);
  }

  encodeNavStop() { return this.frame(0xF1, 0x02, 0x02, [0x00]); }
  encodeSettingsRead(target, offset, expectedSize) { return this.frame(target, 0x01, offset, [expectedSize]); }
}
