import { isNativeAndroid } from './native-bridge.js';

const MAC_PATTERN = /^([0-9A-F]{2}:){5}[0-9A-F]{2}$/;
const connectionHint = isNativeAndroid
  ? 'Android conectará directamente con EKD01 usando esta dirección.'
  : 'Chrome no permite conectar directamente por MAC. Al continuar, elige EKD01 en el selector Bluetooth.';

export class PairingManager {
  constructor() {
    this.video = document.getElementById('qr-video');
    this.canvas = document.getElementById('qr-canvas');
    this.scanTimer = null;
    this.stream = null;
    this.detector = null;
    this.scanning = false;
  }

  async start() {
    this.stop();
    const status = document.getElementById('qr-status');
    const manualInput = document.getElementById('manual-mac-input');
    const retryButton = document.getElementById('btn-retry-camera');
    const connectButton = document.getElementById('btn-pair-connect');
    const viewfinder = document.getElementById('qr-viewfinder');
    const result = document.getElementById('qr-result');

    manualInput.value = '';
    result.classList.add('hidden');
    viewfinder.classList.remove('hidden');
    manualInput.classList.remove('hidden');
    retryButton.classList.add('hidden');
    connectButton.disabled = true;
    status.textContent = 'Escanea el QR del dispositivo o escribe su dirección Bluetooth.';

    if (!window.isSecureContext || !navigator.mediaDevices?.getUserMedia) {
      status.textContent = 'La cámara requiere HTTPS o localhost. Puedes introducir la dirección manualmente.';
      return;
    }

    if ('BarcodeDetector' in window) {
      try {
        const formats = await window.BarcodeDetector.getSupportedFormats();
        if (formats.includes('qr_code')) {
          this.detector = new window.BarcodeDetector({ formats: ['qr_code'] });
        }
      } catch (error) {
        console.warn('BarcodeDetector no disponible; se usará el lector QR alternativo:', error);
      }
    }

    if (!this.detector && typeof window.jsQR !== 'function') {
      status.textContent = 'No se pudo cargar el lector QR. Introduce la dirección manualmente.';
      return;
    }

    try {
      this.stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: { ideal: 'environment' } },
        audio: false
      });
      this.video.srcObject = this.stream;
      await this.video.play();
      this.scanning = true;
      status.textContent = 'Apunta al código QR de la pantalla.';
      this.scan();
    } catch (error) {
      this.stopCamera();
      status.textContent = error.name === 'NotAllowedError'
        ? 'Permiso de cámara denegado. Puedes introducir la dirección manualmente.'
        : `No se pudo iniciar la cámara: ${error.message}`;
      retryButton.classList.remove('hidden');
    }
  }

  async scan() {
    if (!this.scanning) return;
    try {
      if (this.video.videoWidth > 0) {
        this.canvas.width = this.video.videoWidth;
        this.canvas.height = this.video.videoHeight;
        const context = this.canvas.getContext('2d', { willReadFrequently: true });
        context.drawImage(this.video, 0, 0);
        const imageData = context.getImageData(0, 0, this.canvas.width, this.canvas.height);
        const value = this.detector
          ? (await this.detector.detect(this.canvas)).find(code =>
            MAC_PATTERN.test(code.rawValue.trim().toUpperCase())
          )?.rawValue
          : window.jsQR(imageData.data, imageData.width, imageData.height)?.data;
        if (value && MAC_PATTERN.test(value.trim().toUpperCase())) {
          this.showAddress(value.trim().toUpperCase());
          return;
        }
      }
    } catch (error) {
      document.getElementById('qr-status').textContent = `Error al leer el QR: ${error.message}`;
    }
    this.scanTimer = setTimeout(() => this.scan(), 250);
  }

  showAddress(address) {
    document.getElementById('manual-mac-input').value = address;
    document.getElementById('qr-device-mac').textContent = `Dirección detectada: ${address}`;
    document.getElementById('qr-result').classList.remove('hidden');
    document.getElementById('btn-pair-connect').disabled = false;
    document.getElementById('qr-status').textContent = connectionHint;
    this.stopCamera();
    if (navigator.vibrate) navigator.vibrate(50);
  }

  validateManualAddress() {
    const input = document.getElementById('manual-mac-input');
    const address = input.value.trim().toUpperCase();
    const valid = MAC_PATTERN.test(address);
    input.value = address;
    document.getElementById('btn-pair-connect').disabled = !valid;
    if (valid) {
      document.getElementById('qr-device-mac').textContent = `Dirección introducida: ${address}`;
      document.getElementById('qr-result').classList.remove('hidden');
      document.getElementById('qr-status').textContent = connectionHint;
    } else {
      document.getElementById('qr-result').classList.add('hidden');
    }
  }

  stopCamera() {
    this.scanning = false;
    if (this.scanTimer) {
      clearTimeout(this.scanTimer);
      this.scanTimer = null;
    }
    if (this.stream) {
      this.stream.getTracks().forEach(track => track.stop());
      this.stream = null;
    }
    this.video.srcObject = null;
  }

  stop() {
    this.stopCamera();
    this.detector = null;
  }
}
