import { BluetoothManager } from './bluetooth.js';
import { Protocol } from './protocol.js';
import { GpxNavigator } from './gpx-nav.js';
import { PairingManager } from './pairing.js';
import { EkdNav, isNativeAndroid } from './native-bridge.js';

const protocol = new Protocol();
const bluetooth = isNativeAndroid ? new BluetoothManager() : null;
if (bluetooth) bluetooth.protocol = protocol;
const gpxNav = new GpxNavigator(protocol);
const pairing = isNativeAndroid ? new PairingManager() : null;

let map = null;
let mapReady = false;
let markerDestino = null;
let markerUsuario = null;
let markerBicicleta = null;
let routeCoordinates = [];
let routeColor = '#2979ff';
let trailCoordinates = [];
let selectedDestination = null;
let activeDestination = null;
let watchId = null;
let routeRequestVersion = 0;
let reverseGeocodeRequestVersion = 0;
let lastReverseGeocodeAt = 0;
let routeProfileRequestVersion = 0;
let routeProfileSamples = [];
let routeProfileTotalMeters = 0;
let navigationRunning = false;
let automaticReroutingEnabled = false;
let autoRecalculationInProgress = false;
let offRouteSince = null;
let simulatedIndex = 0;
let routeDistances = [];
let progressMeters = 0;
let lastKnownPosition = null;
let lastHeadingPosition = null;
let ultimaInstruccionVoz = '';
let voiceEnabled = true;
let routeProfile = 'trekking';
let routeEstimatedSeconds = null;
let rotationLocked = false;
let rotationToggleButton = null;
let bluetoothReady = false;
let nativeNavigationRequestVersion = 0;
let nativeNavigationActive = false;
let lastBrouterSearchAt = 0;
const NAV_ICON_ROTATION = {
  [protocol.MANEUVER.STRAIGHT]: 0,
  [protocol.MANEUVER.SLIGHT_RIGHT]: 45,
  [protocol.MANEUVER.RIGHT]: 90,
  [protocol.MANEUVER.SHARP_RIGHT]: 135,
  [protocol.MANEUVER.UTURN]: 180,
  [protocol.MANEUVER.SHARP_LEFT]: -135,
  [protocol.MANEUVER.LEFT]: -90,
  [protocol.MANEUVER.SLIGHT_LEFT]: -45
};

// --- Instrucciones de Voz ---
function decirInstruccion(texto) {
  if (voiceEnabled && 'speechSynthesis' in window && texto && texto !== ultimaInstruccionVoz) {
    ultimaInstruccionVoz = texto;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(texto);
    utterance.lang = 'es-ES';
    utterance.rate = 1.05;
    window.speechSynthesis.speak(utterance);
  }
}

function actualizarFuentesMapa() {
  if (!mapReady) return;
  const routeSource = map.getSource('nav-route');
  if (routeSource) {
    routeSource.setData({
      type: 'FeatureCollection',
      features: routeCoordinates.length > 1 ? [{
        type: 'Feature',
        properties: {},
        geometry: { type: 'LineString', coordinates: routeCoordinates.map(point => [point.lon, point.lat]) }
      }] : []
    });
  }
  const trailSource = map.getSource('nav-trail');
  if (trailSource) {
    trailSource.setData({
      type: 'FeatureCollection',
      features: trailCoordinates.length > 1 ? [{
        type: 'Feature',
        properties: {},
        geometry: { type: 'LineString', coordinates: trailCoordinates.map(point => [point.lon, point.lat]) }
      }] : []
    });
  }
  const progressSource = map.getSource('nav-progress');
  if (progressSource) {
    const coordinates = coordenadasProgresoRuta();
    progressSource.setData({
      type: 'FeatureCollection',
      features: coordinates.length > 1 ? [{
        type: 'Feature',
        properties: {},
        geometry: { type: 'LineString', coordinates }
      }] : []
    });
  }
}

function coordenadasProgresoRuta() {
  const points = gpxNav.points;
  if (points.length < 2 || routeDistances.length !== points.length) return [];
  const totalDistance = routeDistances.at(-1) || 0;
  const completedDistance = Math.max(0, Math.min(progressMeters, totalDistance));
  if (completedDistance <= 0) return [];

  const endIndex = routeDistances.findIndex(distance => distance >= completedDistance);
  if (endIndex < 0) return points.map(point => [point.lon, point.lat]);
  const startIndex = Math.max(0, endIndex - 1);
  const startDistance = routeDistances[startIndex];
  const segmentDistance = routeDistances[endIndex] - startDistance;
  const fraction = segmentDistance > 0
    ? (completedDistance - startDistance) / segmentDistance
    : 0;
  const coordinates = points.slice(0, startIndex + 1).map(point => [point.lon, point.lat]);
  const start = points[startIndex];
  const end = points[endIndex];
  coordinates.push([
    start.lon + (end.lon - start.lon) * fraction,
    start.lat + (end.lat - start.lat) * fraction
  ]);
  return coordinates;
}

function prepararFuentesMapa() {
  if (!mapReady) return;
  map.addSource('nav-route', {
    type: 'geojson',
    data: { type: 'FeatureCollection', features: [] }
  });
  map.addLayer({
    id: 'nav-route-line',
    type: 'line',
    source: 'nav-route',
    paint: { 'line-color': routeColor, 'line-width': 6, 'line-opacity': 0.9 },
    layout: { 'line-cap': 'round', 'line-join': 'round' }
  });
  map.addSource('nav-progress', {
    type: 'geojson',
    data: { type: 'FeatureCollection', features: [] }
  });
  map.addLayer({
    id: 'nav-progress-line',
    type: 'line',
    source: 'nav-progress',
    paint: { 'line-color': '#00c853', 'line-width': 7, 'line-opacity': 0.95 },
    layout: { 'line-cap': 'round', 'line-join': 'round' }
  });
  map.addSource('nav-trail', {
    type: 'geojson',
    data: { type: 'FeatureCollection', features: [] }
  });
  map.addLayer({
    id: 'nav-trail-line',
    type: 'line',
    source: 'nav-trail',
    paint: { 'line-color': '#ff6d00', 'line-width': 4, 'line-opacity': 0.95 },
    layout: { 'line-cap': 'round', 'line-join': 'round' }
  });
  actualizarFuentesMapa();
}

function dibujarRuta(coordinates, color) {
  routeCoordinates = coordinates;
  routeColor = color;
  if (mapReady && map.getLayer('nav-route-line')) {
    map.setPaintProperty('nav-route-line', 'line-color', routeColor);
  }
  actualizarFuentesMapa();
  if (coordinates.length > 1 && mapReady) {
    const bounds = new maplibregl.LngLatBounds();
    coordinates.forEach(point => bounds.extend([point.lon, point.lat]));
    map.fitBounds(bounds, { maxZoom: 18, padding: 40 });
  }
}

function actualizarMarcadorDestino(destination) {
  if (!destination) return;
  actualizarInformacionDestino(destination);
  document.getElementById('navRouteName').textContent = destination.name || 'Destino';
  document.getElementById('navDestinationCoords').textContent =
    `${destination.lat.toFixed(5)}, ${destination.lon.toFixed(5)}`;
  if (!mapReady) return;

  if (markerDestino) markerDestino.remove();
  const markerElement = document.createElement('span');
  markerElement.className = 'destination-marker';
  markerElement.setAttribute('role', 'img');
  markerElement.setAttribute('aria-label', `Destino: ${destination.name || 'Destino'}`);
  markerElement.textContent = '📍';

  markerDestino = new maplibregl.Marker({ element: markerElement, anchor: 'bottom' })
    .setLngLat([destination.lon, destination.lat])
    .addTo(map);
}

function actualizarInformacionDestino(destination) {
  const panel = document.getElementById('destinationInfo');
  const name = document.getElementById('destinationInfoName');
  const coordinates = document.getElementById('destinationInfoCoords');
  if (!destination) {
    panel.classList.add('hidden');
    name.textContent = '';
    coordinates.textContent = '';
    return;
  }
  name.textContent = destination.name || 'Destino seleccionado';
  coordinates.textContent = `${destination.lat.toFixed(5)}, ${destination.lon.toFixed(5)}`;
  panel.classList.remove('hidden');
}

function formatDistance(meters) {
  if (!Number.isFinite(meters)) return '--';
  return meters >= 1000 ? `${(meters / 1000).toFixed(1)} km` : `${Math.round(meters)} m`;
}

function formatDuration(seconds) {
  if (!Number.isFinite(seconds) || seconds < 0) return '--';
  const minutes = Math.round(seconds / 60);
  if (minutes < 60) return `~${minutes} min`;
  const hours = Math.floor(minutes / 60);
  const remainingMinutes = minutes % 60;
  return remainingMinutes ? `~${hours} h ${remainingMinutes} min` : `~${hours} h`;
}

function crearElementoSvg(nombre, atributos) {
  const elemento = document.createElementNS('http://www.w3.org/2000/svg', nombre);
  Object.entries(atributos).forEach(([clave, valor]) => elemento.setAttribute(clave, valor));
  return elemento;
}

function muestrearRuta(points, maxPoints = 100) {
  let distance = 0;
  const measured = points.map((point, index) => {
    if (index > 0) distance += gpxNav.haversine(points[index - 1], point);
    return { ...point, distance };
  });
  if (measured.length <= maxPoints) return measured;
  return Array.from({ length: maxPoints }, (_, index) =>
    measured[Math.round(index * (measured.length - 1) / (maxPoints - 1))]
  );
}

async function prepararPerfilRuta(points) {
  const requestId = ++routeProfileRequestVersion;
  const chart = document.getElementById('routeProfileChart');
  const status = document.getElementById('routeProfileStatus');
  chart.replaceChildren();
  routeProfileSamples = [];
  const samples = muestrearRuta(points);
  routeProfileTotalMeters = samples.at(-1)?.distance || 0;
  if (samples.length < 2) {
    status.textContent = 'La ruta no tiene puntos suficientes para mostrar el perfil.';
    actualizarProgresoVisual();
    return;
  }

  const missing = samples.filter(point => !Number.isFinite(point.ele));
  let elevationError = '';
  if (missing.length > 0) {
    const params = new URLSearchParams({
      latitude: missing.map(point => point.lat).join(','),
      longitude: missing.map(point => point.lon).join(',')
    });
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 15000);
    try {
      const response = await fetch(`https://api.open-meteo.com/v1/elevation?${params}`, {
        signal: controller.signal
      });
      if (!response.ok) throw new Error(`El servicio de altitud respondió ${response.status}.`);
      const data = await response.json();
      if (requestId !== routeProfileRequestVersion) return;
      if (!Array.isArray(data.elevation) || data.elevation.length !== missing.length) {
        throw new Error('El servicio de altitud devolvió datos incompletos.');
      }
      missing.forEach((point, index) => {
        if (Number.isFinite(data.elevation[index])) point.ele = data.elevation[index];
      });
    } catch (error) {
      if (requestId !== routeProfileRequestVersion) return;
      elevationError = error.message;
      console.error('No se pudo obtener la altitud de la ruta:', error);
    } finally {
      clearTimeout(timeoutId);
    }
  }

  if (requestId !== routeProfileRequestVersion) return;
  const profile = samples.filter(point => Number.isFinite(point.ele));
  if (profile.length < 2) {
    status.textContent = elevationError
      ? `No se pudo cargar el perfil de elevación: ${elevationError}`
      : 'No hay datos de altitud disponibles para esta ruta.';
    actualizarProgresoVisual();
    return;
  }

  const width = 600, height = 100;
  const left = 10, right = 10, top = 8, bottom = 8;
  const rawMin = Math.min(...profile.map(point => point.ele));
  const rawMax = Math.max(...profile.map(point => point.ele));
  const range = Math.max(rawMax - rawMin, 1);
  const minElevation = rawMin - range * 0.08;
  const maxElevation = rawMax + range * 0.08;
  const plotWidth = width - left - right;
  const plotHeight = height - top - bottom;
  routeProfileSamples = profile.map(point => ({
    distance: point.distance,
    x: left + (routeProfileTotalMeters > 0 ? point.distance / routeProfileTotalMeters : 0) * plotWidth,
    y: top + (maxElevation - point.ele) / (maxElevation - minElevation) * plotHeight
  }));
  const linePoints = routeProfileSamples.map(point => `${point.x},${point.y}`).join(' ');
  const areaPoints = `${left},${height - bottom} ${linePoints} ${left + plotWidth},${height - bottom}`;
  chart.appendChild(crearElementoSvg('polygon', { points: areaPoints, class: 'route-profile-area' }));
  chart.appendChild(crearElementoSvg('polyline', { points: linePoints, class: 'route-profile-line' }));
  chart.appendChild(crearElementoSvg('line', {
    id: 'routeProfileProgressLine',
    x1: left, x2: left, y1: top, y2: height - bottom,
    class: 'route-profile-progress-line'
  }));
  chart.appendChild(crearElementoSvg('circle', {
    id: 'routeProfileProgressPoint',
    cx: left, cy: routeProfileSamples[0].y, r: 4,
    class: 'route-profile-progress-point'
  }));
  status.textContent = elevationError
    ? `Perfil parcial; no se pudieron obtener todas las altitudes.`
    : `${Math.round(rawMin)}–${Math.round(rawMax)} m de altitud`;
  actualizarProgresoVisual();
}

function actualizarProgresoVisual() {
  const totalDistance = routeProfileTotalMeters || routeDistances.at(-1) || 0;
  const completedDistance = Math.max(0, Math.min(progressMeters, totalDistance));
  const percent = totalDistance > 0 ? Math.round(completedDistance / totalDistance * 100) : 0;
  const label = `${percent}% · ${formatDistance(completedDistance)} / ${formatDistance(totalDistance)}`;
  const profileProgress = document.getElementById('routeProfileProgress');
  const mapProgressLabel = document.getElementById('mapProgressLabel');
  const mapProgressBar = document.getElementById('mapProgressBar');
  if (profileProgress) profileProgress.textContent = label;
  if (mapProgressLabel) mapProgressLabel.textContent = label;
  if (mapProgressBar) mapProgressBar.value = percent;

  const point = routeProfileSamples[0];
  const progressLine = document.getElementById('routeProfileProgressLine');
  const progressPoint = document.getElementById('routeProfileProgressPoint');
  if (!point || !progressLine || !progressPoint) return;
  const distance = completedDistance;
  let nextIndex = routeProfileSamples.findIndex(sample => sample.distance >= distance);
  if (nextIndex < 0) nextIndex = routeProfileSamples.length - 1;
  const start = routeProfileSamples[Math.max(0, nextIndex - 1)];
  const end = routeProfileSamples[nextIndex];
  const span = end.distance - start.distance;
  const fraction = span > 0 ? (distance - start.distance) / span : 0;
  const x = start.x + (end.x - start.x) * fraction;
  const y = start.y + (end.y - start.y) * fraction;
  progressLine.setAttribute('x1', String(x));
  progressLine.setAttribute('x2', String(x));
  progressPoint.setAttribute('cx', String(x));
  progressPoint.setAttribute('cy', String(y));
}

function actualizarIconoInstruccion() {
  const icon = document.getElementById('navTurnIcon');
  if (!icon) return;
  const path = icon.querySelector('path');
  const turn = gpxNav.turns.find(item => item.distFromStart > progressMeters);
  const maneuver = turn?.code ?? protocol.MANEUVER.STRAIGHT;
  const arrived = maneuver === protocol.MANEUVER.ARRIVE;
  path.setAttribute('d', arrived
    ? 'M12 2.5 14.9 8.4 21.5 9.4 16.8 14l1.1 6.6-5.9-3.1-5.9 3.1L7.2 14 2.5 9.4l6.6-1z'
    : 'M12 2 3 12h6v10h6V12h6z');
  icon.style.transform = arrived ? '' : `rotate(${NAV_ICON_ROTATION[maneuver] || 0}deg)`;
  icon.classList.toggle('arrived', arrived);
  icon.setAttribute('aria-label', turn?.label || (arrived ? 'Destino alcanzado' : 'Sigue recto'));
}

function actualizarResumenNavegacion(instruction = '') {
  const totalMeters = routeDistances.at(-1) || 0;
  const remainingMeters = Math.max(0, totalMeters - progressMeters);
  const estimatedSeconds = routeEstimatedSeconds !== null && totalMeters > 0
    ? routeEstimatedSeconds * remainingMeters / totalMeters
    : remainingMeters / (15000 / 3600);
  const turnText = instruction.split('|')[0].trim();
  document.getElementById('navNextTurn').textContent = turnText || 'Sigue la ruta';
  document.getElementById('navSubinstruction').textContent = turnText
    ? 'Próximo giro'
    : 'Inicia una ruta para ver la próxima indicación.';
  actualizarIconoInstruccion();
  document.getElementById('navTotalDistance').textContent = formatDistance(totalMeters);
  document.getElementById('navRemainingDistance').textContent = formatDistance(remainingMeters);
  document.getElementById('navEstimatedTime').textContent = formatDuration(estimatedSeconds);
  actualizarProgresoVisual();
}

function actualizarOrientacionMapa(position, gpsHeading = null) {
  if (!mapReady || !navigationRunning || rotationLocked) return;
  let heading = Number.isFinite(gpsHeading) && gpsHeading >= 0 ? gpsHeading : null;
  if (heading === null && lastHeadingPosition) {
    const movement = gpxNav.haversine(lastHeadingPosition, position);
    if (movement >= 4) heading = gpxNav.bearing(lastHeadingPosition, position);
  }
  lastHeadingPosition = position;
  if (heading !== null) map.rotateTo(heading, { duration: 500 });
}

function actualizarMarcadorUsuario(position) {
  if (!mapReady) return;
  if (!markerUsuario) {
    const element = document.createElement('span');
    element.className = 'user-marker';
    element.setAttribute('aria-label', 'Tu ubicación');
    markerUsuario = new maplibregl.Marker({ element, anchor: 'center' }).setLngLat(position).addTo(map);
  } else {
    markerUsuario.setLngLat(position);
  }
}

function actualizarMarcadorBicicleta(position) {
  if (!mapReady) return;
  if (!markerBicicleta) {
    const element = document.createElement('span');
    element.className = 'bike-marker';
    element.setAttribute('role', 'img');
    element.setAttribute('aria-label', 'Posición actual de la bicicleta');
    element.textContent = '🚴';
    markerBicicleta = new maplibregl.Marker({ element, anchor: 'center' }).setLngLat(position).addTo(map);
  } else {
    markerBicicleta.setLngLat(position);
  }
}

function actualizarProgresoRuta(position) {
  if (gpxNav.points.length < 2) return;
  let closestDistance = Infinity;
  let closestProgress = progressMeters;
  let closestIndex = simulatedIndex;
  const latScale = 111320;
  const lonScale = latScale * Math.cos(position.lat * Math.PI / 180);

  for (let i = Math.max(0, simulatedIndex - 2); i < gpxNav.points.length - 1; i++) {
    const start = gpxNav.points[i];
    const end = gpxNav.points[i + 1];
    const ax = (start.lon - position.lon) * lonScale;
    const ay = (start.lat - position.lat) * latScale;
    const bx = (end.lon - position.lon) * lonScale;
    const by = (end.lat - position.lat) * latScale;
    const dx = bx - ax;
    const dy = by - ay;
    const lengthSquared = dx * dx + dy * dy;
    const fraction = lengthSquared === 0 ? 0 : Math.max(0, Math.min(1, -(ax * dx + ay * dy) / lengthSquared));
    const distance = Math.hypot(ax + fraction * dx, ay + fraction * dy);
    if (distance < closestDistance) {
      closestDistance = distance;
      closestProgress = routeDistances[i] + fraction * (routeDistances[i + 1] - routeDistances[i]);
      closestIndex = i;
    }
  }

  if (closestDistance <= toleranciaSeguimiento(position.accuracy)) {
    progressMeters = Math.max(progressMeters, closestProgress);
    simulatedIndex = Math.max(simulatedIndex, closestIndex);
  }
  return closestDistance;
}

function toleranciaSeguimiento(accuracy) {
  return Number.isFinite(accuracy) ? Math.max(50, Math.min(accuracy, 100)) : 50;
}

function comprobarDesvioRuta(distanceFromRoute, accuracy) {
  if (!navigationRunning || !automaticReroutingEnabled || autoRecalculationInProgress) {
    offRouteSince = null;
    return;
  }
  if (distanceFromRoute <= toleranciaSeguimiento(accuracy)) {
    offRouteSince = null;
    return;
  }
  if (offRouteSince === null) {
    offRouteSince = Date.now();
    return;
  }
  if (Date.now() - offRouteSince >= 5000) {
    offRouteSince = null;
    recalcularRuta(true);
  }
}

// --- Inicialización del Mapa ---
async function initMap() {
  if (map) return;
  try {
    const response = await fetch('https://tiles.openfreemap.org/styles/liberty');
    if (!response.ok) throw new Error(`El servicio de mapas respondió ${response.status}.`);
    const style = await response.json();
    style.layers = style.layers.filter(layer => layer.type !== 'raster');
    Object.keys(style.sources).forEach(sourceId => {
      if (style.sources[sourceId].type === 'raster') delete style.sources[sourceId];
    });

    map = new maplibregl.Map({
      container: 'mapa',
      style,
      center: [-2.988, 43.293],
      zoom: 14,
      minZoom: 5,
      maxZoom: 20,
      attributionControl: false
    });
    map.addControl(new maplibregl.NavigationControl({ showCompass: false }), 'top-right');
    map.addControl(new maplibregl.AttributionControl({ compact: true }), 'bottom-right');
    const rotationControl = document.createElement('div');
    rotationControl.className = 'maplibregl-ctrl maplibregl-ctrl-group';
    rotationToggleButton = document.createElement('button');
    rotationToggleButton.type = 'button';
    rotationToggleButton.className = 'map-rotation-toggle';
    rotationToggleButton.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="m15.5 8.5-2.3 4.7-4.7 2.3 2.3-4.7z" fill="currentColor"/></svg>';
    rotationToggleButton.addEventListener('click', event => {
      event.preventDefault();
      event.stopPropagation();
      setMapRotationLocked(!rotationLocked);
    });
    rotationControl.appendChild(rotationToggleButton);
    map.getContainer().querySelector('.maplibregl-ctrl-top-right').appendChild(rotationControl);
    setMapRotationLocked(rotationLocked);
    map.on('click', event => {
      if (document.getElementById('plannerScreen').classList.contains('hidden')) return;
      const coordinates = `${event.lngLat.lat.toFixed(5)}, ${event.lngLat.lng.toFixed(5)}`;
      selectedDestination = {
        lat: event.lngLat.lat,
        lon: event.lngLat.lng,
        name: coordinates
      };
      document.getElementById('inputBuscador').value = selectedDestination.name;
      document.getElementById('btnAbrirNavegacion').disabled = true;
      actualizarMarcadorDestino(selectedDestination);
      buscarDireccionDestino(selectedDestination);
    });
    map.on('load', () => {
      mapReady = true;
      prepararFuentesMapa();
      dibujarRuta(routeCoordinates, routeColor);
      if (lastKnownPosition) {
        map.flyTo({ center: [lastKnownPosition.lon, lastKnownPosition.lat], zoom: 15 });
        actualizarMarcadorUsuario([lastKnownPosition.lon, lastKnownPosition.lat]);
      }
      const destination = activeDestination || selectedDestination;
      if (destination) actualizarMarcadorDestino(destination);
    });
    map.on('error', event => console.error('Error al cargar el mapa vectorial:', event.error));
  } catch (error) {
    console.error('No se pudo inicializar el mapa vectorial:', error);
    document.getElementById('mapa').textContent = 'No se pudo cargar el mapa vectorial. Comprueba tu conexión e inténtalo de nuevo.';
  }

  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(pos => {
      lastKnownPosition = { lat: pos.coords.latitude, lon: pos.coords.longitude };
      if (mapReady) {
        map.flyTo({ center: [lastKnownPosition.lon, lastKnownPosition.lat], zoom: 15 });
        actualizarMarcadorUsuario([lastKnownPosition.lon, lastKnownPosition.lat]);
      }
    }, () => {}, { timeout: 5000 });
  }
}

function setMapRotationLocked(locked) {
  rotationLocked = locked;
  if (rotationLocked) {
    map.dragRotate.disable();
    map.touchZoomRotate.disableRotation();
    map.resetNorth({ duration: 250 });
  } else {
    map.dragRotate.enable();
    map.touchZoomRotate.enableRotation();
  }
  rotationToggleButton.classList.toggle('rotation-locked', rotationLocked);
  rotationToggleButton.classList.toggle('rotation-enabled', !rotationLocked);
  rotationToggleButton.setAttribute('aria-pressed', String(rotationLocked));
  rotationToggleButton.setAttribute(
    'aria-label',
    rotationLocked ? 'Activar giro del mapa' : 'Bloquear giro del mapa'
  );
  rotationToggleButton.title = rotationLocked ? 'Giro bloqueado; tocar para activar la rotación' : 'Giro activado; tocar para bloquearlo';
}

// --- Autocompletar Direcciones ---
async function buscarDestinoPorTexto(query) {
  const params = new URLSearchParams({
    format: 'json',
    q: query,
    limit: '1'
  });
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 15000);
  let response;
  try {
    response = await fetch(`https://nominatim.openstreetmap.org/search?${params}`, {
      headers: { 'Accept-Language': 'es' },
      signal: controller.signal
    });
  } finally {
    clearTimeout(timeoutId);
  }
  if (!response.ok) throw new Error(`El servicio de direcciones respondió ${response.status}.`);
  const [result] = await response.json();
  if (!result) throw new Error('No se encontró ese destino.');
  const lat = Number(result.lat);
  const lon = Number(result.lon);
  if (!Number.isFinite(lat) || !Number.isFinite(lon)) {
    throw new Error('El servicio de direcciones devolvió coordenadas no válidas.');
  }
  return { lat, lon, name: result.display_name };
}

async function buscarDireccionDestino(destination) {
  const requestId = ++reverseGeocodeRequestVersion;
  const wait = Math.max(0, 1000 - (Date.now() - lastReverseGeocodeAt));
  if (wait) await new Promise(resolve => setTimeout(resolve, wait));
  if (requestId !== reverseGeocodeRequestVersion) return;
  lastReverseGeocodeAt = Date.now();

  const params = new URLSearchParams({
    lat: String(destination.lat),
    lon: String(destination.lon),
    format: 'jsonv2'
  });
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 15000);
  try {
    const response = await fetch(`https://nominatim.openstreetmap.org/reverse?${params}`, {
      headers: { 'Accept-Language': 'es' },
      signal: controller.signal
    });
    if (!response.ok) throw new Error(`El servicio de direcciones respondió ${response.status}.`);
    const result = await response.json();
    if (requestId !== reverseGeocodeRequestVersion ||
        selectedDestination?.lat !== destination.lat ||
        selectedDestination?.lon !== destination.lon) return;
    const address = result.display_name?.trim();
    if (!address) return;
    selectedDestination = { ...selectedDestination, name: address };
    document.getElementById('inputBuscador').value = address;
    actualizarMarcadorDestino(selectedDestination);
  } catch (error) {
    if (requestId === reverseGeocodeRequestVersion) {
      console.error('No se pudo obtener la dirección del punto seleccionado:', error);
    }
  } finally {
    clearTimeout(timeoutId);
  }
}

function setupAutocomplete() {
  const input = document.getElementById('inputBuscador');
  const datalist = document.getElementById('sugerenciasDestino');
  let timeoutId = null;

  input.addEventListener('input', (e) => {
    const query = e.target.value.trim();
    reverseGeocodeRequestVersion++;
    if (selectedDestination && selectedDestination.name !== query) {
      selectedDestination = null;
      document.getElementById('btnAbrirNavegacion').disabled = true;
      actualizarInformacionDestino(null);
    }
    if (query.length < 3) return;

    clearTimeout(timeoutId);
    timeoutId = setTimeout(async () => {
      try {
        const res = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}&limit=5`, {
          headers: { 'Accept-Language': 'es' }
        });
        const data = await res.json();
        datalist.innerHTML = '';
        data.forEach(item => {
          const opt = document.createElement('option');
          opt.value = item.display_name;
          opt.dataset.lat = item.lat;
          opt.dataset.lon = item.lon;
          datalist.appendChild(opt);
        });
      } catch (err) {
        console.error('Error autocompletar:', err);
      }
    }, 300);
  });

  input.addEventListener('change', (e) => {
    const val = e.target.value;
    for (let opt of datalist.options) {
      if (opt.value === val) {
        selectedDestination = {
          lat: parseFloat(opt.dataset.lat),
          lon: parseFloat(opt.dataset.lon),
          name: val
        };
        if (map) map.flyTo({ center: [selectedDestination.lon, selectedDestination.lat], zoom: 15 });
        actualizarMarcadorDestino(selectedDestination);
        break;
      }
    }
  });
}

// --- Calcular ruta urbana en bicicleta ---
async function calcularRutaYNavegar(
  destLat,
  destLon,
  startPosition = null,
  requestVersion = null,
  enableAutomaticRerouting = true
) {
  const requestId = requestVersion === null ? ++routeRequestVersion : requestVersion;
  try {
    let startLat = 43.293, startLon = -2.988;
    if (startPosition) {
      startLat = startPosition.lat;
      startLon = startPosition.lon;
    } else if (navigator.geolocation) {
      try {
        const pos = await new Promise((res, rej) => navigator.geolocation.getCurrentPosition(res, rej, { timeout: 4000 }));
        startLat = pos.coords.latitude;
        startLon = pos.coords.longitude;
      } catch (_) {}
    }

    const url = new URL('https://brouter.de/brouter');
    url.search = new URLSearchParams({
      lonlats: `${startLon},${startLat}|${destLon},${destLat}`,
      profile: routeProfile,
      alternativeidx: '0',
      format: 'geojson'
    });
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 30000);
    let response;
    try {
      response = await fetch(url, { signal: controller.signal });
    } finally {
      clearTimeout(timeoutId);
    }
    if (requestId !== routeRequestVersion) return;
    if (!response.ok) throw new Error(`El servicio BRouter respondió ${response.status}.`);
    const data = await response.json();
    if (requestId !== routeRequestVersion) return;
    const route = data.features?.find(feature =>
      feature.geometry?.type === 'LineString' && feature.geometry.coordinates?.length >= 2
    );
    if (!route) throw new Error('BRouter no encontró una ruta para este destino y perfil.');

    const coordinates = route.geometry.coordinates.map(c => ({ lat: c[1], lon: c[0], ele: c[2] }));
    const estimatedSeconds = Number(route.properties?.['total-time']);
    routeEstimatedSeconds = Number.isFinite(estimatedSeconds) && estimatedSeconds > 0 ? estimatedSeconds : null;
    activeDestination = {
      lat: destLat,
      lon: destLon,
      name: selectedDestination?.lat === destLat && selectedDestination?.lon === destLon
        ? selectedDestination.name
        : 'Destino'
    };
    automaticReroutingEnabled = enableAutomaticRerouting;

    let gpxXml = `<?xml version="1.0" encoding="UTF-8"?><gpx version="1.1"><trk><trkseg>`;
    coordinates.forEach(c => {
      gpxXml += `<trkpt lat="${c.lat}" lon="${c.lon}">`;
      if (Number.isFinite(c.ele)) gpxXml += `<ele>${c.ele}</ele>`;
      gpxXml += '</trkpt>';
    });
    gpxXml += `</trkseg></trk></gpx>`;

    gpxNav.loadGpxText(gpxXml);
    simulatedIndex = 0;
    progressMeters = 0;

    dibujarRuta(coordinates, '#2979ff');
    document.getElementById('btnAbrirNavegacion').disabled = false;
    actualizarMarcadorDestino(activeDestination);

    iniciarSeguimientoGps();
    abrirPantallaNavegacion();
  } catch (err) {
    if (requestId === routeRequestVersion) alert('Error al calcular la ruta: ' + err.message);
  }
}

async function recalcularRuta(automatic = false) {
  if (automatic && (!navigationRunning || !automaticReroutingEnabled || autoRecalculationInProgress)) return;
  if (!activeDestination) {
    alert('No hay un destino activo para recalcular la ruta.');
    return;
  }
  if (!navigator.geolocation) {
    alert('Este dispositivo no ofrece GPS para recalcular la ruta.');
    return;
  }

  const button = document.getElementById('btnRecalcularRuta');
  const requestId = ++routeRequestVersion;
  offRouteSince = null;
  autoRecalculationInProgress = automatic;
  button.disabled = true;
  button.textContent = 'Recalculando...';
  if (automatic) document.getElementById('infoGiro').textContent = 'Fuera de ruta; recalculando...';
  try {
    const position = await new Promise((resolve, reject) => {
      navigator.geolocation.getCurrentPosition(resolve, reject, {
        enableHighAccuracy: true,
        maximumAge: 0,
        timeout: 12000
      });
    });
    if (requestId !== routeRequestVersion) return;
    await calcularRutaYNavegar(
      activeDestination.lat,
      activeDestination.lon,
      { lat: position.coords.latitude, lon: position.coords.longitude },
      requestId,
      automaticReroutingEnabled
    );
  } catch (error) {
    if (requestId === routeRequestVersion) {
      console.error('Error al obtener la posición para recalcular:', error);
      alert(`No se pudo recalcular la ruta: ${error.message}`);
    }
  } finally {
    autoRecalculationInProgress = false;
    button.disabled = false;
    button.textContent = '↻ Recalcular';
  }
}

// --- Seguimiento GPS y Envío a Pantalla ---
function iniciarSeguimientoGps() {
  if (gpxNav.points.length === 0) return;

  if (watchId !== null) navigator.geolocation.clearWatch(watchId);
  navigationRunning = true;
  document.getElementById('btnPararNavPantalla').disabled = false;
  offRouteSince = null;
  simulatedIndex = 0;
  progressMeters = 0;
  routeDistances = [0];
  for (let i = 1; i < gpxNav.points.length; i++) {
    routeDistances.push(routeDistances[i - 1] + gpxNav.haversine(gpxNav.points[i - 1], gpxNav.points[i]));
  }
  prepararPerfilRuta(gpxNav.points);
  if (routeEstimatedSeconds === null) routeEstimatedSeconds = routeDistances.at(-1) / (15000 / 3600);
  lastHeadingPosition = lastKnownPosition;
  const initialNavInfo = gpxNav.getNavFrameForDistance(0);
  document.getElementById('infoGiro').textContent = initialNavInfo.info;
  actualizarResumenNavegacion(initialNavInfo.info);
  trailCoordinates = [];
  actualizarFuentesMapa();
  ultimaInstruccionVoz = '';
  document.getElementById('btnPararNav').style.display = 'block';
  document.getElementById('btnRecalcularRuta').style.display = activeDestination ? 'inline-block' : 'none';
  if (isNativeAndroid) {
    iniciarServicioNavegacionNativo();
    return;
  }
  decirInstruccion('Ruta iniciada.');

  iniciarSeguimientoGpsWeb();
}

function iniciarSeguimientoGpsWeb() {
  if (!navigator.geolocation) return;
  if (watchId !== null) navigator.geolocation.clearWatch(watchId);
  watchId = navigator.geolocation.watchPosition(async (pos) => {
    const currentPos = {
      lat: pos.coords.latitude,
      lon: pos.coords.longitude,
      accuracy: pos.coords.accuracy
    };
    actualizarOrientacionMapa(currentPos, pos.coords.heading);
    lastKnownPosition = currentPos;
    const speedKmh = (pos.coords.speed || 0) * 3.6;
    document.getElementById('valVelocidad').textContent = speedKmh.toFixed(1);
    actualizarMarcadorUsuario([currentPos.lon, currentPos.lat]);
    actualizarMarcadorBicicleta([currentPos.lon, currentPos.lat]);
    trailCoordinates.push(currentPos);
    const distanceFromRoute = actualizarProgresoRuta(currentPos);
    actualizarFuentesMapa();
    if (!isNativeAndroid || !nativeNavigationActive) {
      comprobarDesvioRuta(distanceFromRoute, currentPos.accuracy);
    }

    const navInfo = gpxNav.getNavFrameForDistance(progressMeters);
    document.getElementById('infoGiro').textContent = navInfo.info;
    actualizarResumenNavegacion(navInfo.info);
    decirInstruccion(navInfo.voiceInfo || navInfo.info.split('|')[0]);

    if (bluetooth?.connected && bluetoothReady && (!isNativeAndroid || !nativeNavigationActive)) {
      try {
        await bluetooth.write(navInfo.frame);
      } catch (error) {
        console.error('Error al enviar navegación por BLE:', error);
        document.getElementById('estadoConexion').textContent = '● Error de conexión';
        document.getElementById('estadoConexion').style.color = '#ff8a80';
      }
    }
  }, (err) => console.error('GPS error:', err), { enableHighAccuracy: true, maximumAge: 1000, timeout: 10000 });
}

function iniciarServicioNavegacionNativo() {
  const requestVersion = ++nativeNavigationRequestVersion;
  const route = {
    points: gpxNav.points.map(({ lat, lon, ele }) => ({ lat, lon, ele })),
    turns: gpxNav.turns.map(({ index, distFromStart, code, label }) => ({ index, distFromStart, code, label })),
    destination: activeDestination ? { lat: activeDestination.lat, lon: activeDestination.lon } : null,
    automaticRerouting: automaticReroutingEnabled,
    routeColor,
    voiceEnabled
  };
  EkdNav.startNavigation(route).then(() => {
    if (requestVersion !== nativeNavigationRequestVersion) {
      if (navigationRunning) iniciarServicioNavegacionNativo();
      else EkdNav.stopNavigation().catch(error => console.error('No se pudo detener el servicio nativo:', error));
      return;
    }
    nativeNavigationActive = true;
  }).catch(error => {
    if (requestVersion !== nativeNavigationRequestVersion) return;
    nativeNavigationActive = false;
    console.error('No se pudo iniciar el servicio de navegación Android:', error);
    document.getElementById('infoGiro').textContent = 'El GPS en segundo plano no está disponible: ' + error.message;
    if (navigationRunning) {
      decirInstruccion('Ruta iniciada.');
      iniciarSeguimientoGpsWeb();
    }
  });
}

function aplicarEstadoNavegacionNativo(status) {
  if (!status || !status.running) {
    if (navigationRunning) {
      navigationRunning = false;
      nativeNavigationActive = false;
      document.getElementById('btnPararNavPantalla').disabled = true;
      document.getElementById('btnPararNav').style.display = 'none';
      document.getElementById('btnRecalcularRuta').style.display = 'none';
      document.getElementById('infoGiro').textContent = 'El servicio de navegación Android se ha detenido.';
    }
    return;
  }
  if (!Array.isArray(status.points) || status.points.length < 2) return;
  gpxNav.points = status.points;
  gpxNav.turns = Array.isArray(status.turns) ? status.turns : [];
  const destinationPoint = status.points.at(-1);
  activeDestination = status.destination || {
    lat: destinationPoint.lat,
    lon: destinationPoint.lon,
    name: 'Destino de la ruta'
  };
  actualizarMarcadorDestino(activeDestination);
  automaticReroutingEnabled = Boolean(status.automaticRerouting);
  voiceEnabled = status.voiceEnabled !== false;
  actualizarBotonVoz();
  routeColor = status.routeColor || (automaticReroutingEnabled ? '#2979ff' : '#00c853');
  navigationRunning = true;
  nativeNavigationActive = true;
  document.getElementById('btnAbrirNavegacion').disabled = false;
  document.getElementById('btnPararNavPantalla').disabled = false;
  document.getElementById('navRouteName').textContent = activeDestination?.name || 'Ruta GPX';
  progressMeters = Number(status.progressMeters) || 0;
  routeDistances = [0];
  for (let i = 1; i < gpxNav.points.length; i++) {
    routeDistances.push(routeDistances[i - 1] + gpxNav.haversine(gpxNav.points[i - 1], gpxNav.points[i]));
  }
  prepararPerfilRuta(gpxNav.points);
  actualizarResumenNavegacion(status.info || '');
  dibujarRuta(gpxNav.points, routeColor);
  document.getElementById('btnPararNav').style.display = 'block';
  document.getElementById('btnRecalcularRuta').style.display = activeDestination ? 'inline-block' : 'none';
  if (status.info) document.getElementById('infoGiro').textContent = status.info;
  if (Number.isFinite(status.latitude) && Number.isFinite(status.longitude)) {
    actualizarPosicionDesdeNativo(status);
  }
}

function actualizarPosicionDesdeNativo(position) {
  const currentPos = { lat: position.latitude, lon: position.longitude };
  actualizarOrientacionMapa(currentPos, position.heading);
  lastKnownPosition = currentPos;
  if (Number.isFinite(position.progressMeters)) progressMeters = Math.max(progressMeters, position.progressMeters);
  actualizarProgresoVisual();
  document.getElementById('valVelocidad').textContent = (Number(position.speedKmh) || 0).toFixed(1);
  actualizarMarcadorUsuario([currentPos.lon, currentPos.lat]);
  actualizarMarcadorBicicleta([currentPos.lon, currentPos.lat]);
  trailCoordinates.push(currentPos);
  actualizarFuentesMapa();
  if (position.info) {
    document.getElementById('infoGiro').textContent = position.info;
    actualizarResumenNavegacion(position.info);
  }
}

function actualizarBotonVoz() {
  const btnVoz = document.getElementById('btnVoz');
  if (!btnVoz) return;
  btnVoz.textContent = voiceEnabled ? 'Voz: activada' : 'Voz: desactivada';
  btnVoz.setAttribute('aria-pressed', String(voiceEnabled));
  btnVoz.setAttribute('aria-label', voiceEnabled ? 'Desactivar voz' : 'Activar voz');
  const navVoiceButton = document.getElementById('btnVozNav');
  if (navVoiceButton) {
    navVoiceButton.textContent = voiceEnabled ? 'Voz: activada' : 'Voz: desactivada';
    navVoiceButton.setAttribute('aria-pressed', String(voiceEnabled));
  }
}

function detenerNavegacion() {
  routeRequestVersion++;
  navigationRunning = false;
  offRouteSince = null;
  autoRecalculationInProgress = false;
  if (watchId !== null) {
    navigator.geolocation.clearWatch(watchId);
    watchId = null;
  }
  if (isNativeAndroid) {
    nativeNavigationRequestVersion++;
    nativeNavigationActive = false;
    EkdNav.stopNavigation().catch(error => console.error('No se pudo detener el servicio nativo:', error));
  }
  if (bluetooth?.connected && !isNativeAndroid) {
    bluetooth.write(protocol.encodeNavStop()).catch(err => console.error('Error al detener navegación BLE:', err));
  }
  document.getElementById('btnPararNav').style.display = 'none';
  document.getElementById('btnRecalcularRuta').style.display = 'none';
  document.getElementById('btnPararNavPantalla').disabled = true;
  document.getElementById('btnRecalcularNav').style.display = 'none';
  document.getElementById('infoGiro').textContent = 'Navegación detenida';
  actualizarResumenNavegacion('Navegación detenida');
  decirInstruccion('Navegación detenida');
}

function abrirPantallaNavegacion() {
  const planner = document.getElementById('plannerScreen');
  const navigationScreen = document.getElementById('navigationScreen');
  const workspace = document.getElementById('workspace');
  if (document.getElementById('btnAbrirNavegacion').disabled) return;
  planner.classList.add('hidden');
  navigationScreen.classList.remove('hidden');
  workspace.classList.add('navigation-mode');
  document.getElementById('navigationMapHost').appendChild(workspace);
  document.getElementById('btnPararNavPantalla').disabled = !navigationRunning;
  document.getElementById('btnRecalcularNav').style.display = activeDestination && navigationRunning ? 'inline-block' : 'none';
  actualizarMarcadorDestino(activeDestination || selectedDestination);
  actualizarResumenNavegacion(document.getElementById('infoGiro').textContent);
  if (map) requestAnimationFrame(() => map.resize());
}

function volverAPlanificacion() {
  const planner = document.getElementById('plannerScreen');
  const navigationScreen = document.getElementById('navigationScreen');
  const workspace = document.getElementById('workspace');
  planner.insertBefore(workspace, document.getElementById('planningFooter'));
  workspace.classList.remove('navigation-mode');
  navigationScreen.classList.add('hidden');
  planner.classList.remove('hidden');
  if (map) requestAnimationFrame(() => map.resize());
}

function tilesParaRegion(bounds) {
  const [west, south, east, north] = bounds;
  const tiles = [];
  const firstLon = Math.floor(west / 5) * 5;
  const lastLon = Math.floor((east - 1e-8) / 5) * 5;
  const firstLat = Math.floor(south / 5) * 5;
  const lastLat = Math.floor((north - 1e-8) / 5) * 5;
  for (let lon = firstLon; lon <= lastLon; lon += 5) {
    for (let lat = firstLat; lat <= lastLat; lat += 5) {
      const lonLabel = `${lon < 0 ? 'W' : 'E'}${Math.abs(lon)}`;
      const latLabel = `${lat < 0 ? 'S' : 'N'}${Math.abs(lat)}`;
      tiles.push(`${lonLabel}_${latLabel}.rd5`);
    }
  }
  return tiles;
}

async function buscarRegionesBrouter() {
  const queryInput = document.getElementById('inputRegionBrouter');
  const select = document.getElementById('selectRegionBrouter');
  const downloadButton = document.getElementById('btnDescargarDatosBrouter');
  const searchButton = document.getElementById('btnBuscarRegionBrouter');
  const status = document.getElementById('estadoDatosBrouter');
  const query = queryInput.value.trim();
  if (query.length < 2) {
    status.textContent = 'Escribe al menos dos caracteres para buscar.';
    return;
  }

  searchButton.disabled = true;
  downloadButton.disabled = true;
  select.disabled = true;
  select.replaceChildren(new Option('Buscando…', ''));
  status.textContent = 'Buscando país o región en todo el mundo…';
  try {
    const wait = Math.max(0, 1000 - (Date.now() - lastBrouterSearchAt));
    if (wait) await new Promise(resolve => setTimeout(resolve, wait));
    lastBrouterSearchAt = Date.now();
    const params = new URLSearchParams({
      q: query,
      format: 'jsonv2',
      limit: '10',
      addressdetails: '1'
    });
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 15000);
    let response;
    try {
      response = await fetch(`https://nominatim.openstreetmap.org/search?${params}`, {
        headers: { 'Accept-Language': 'es' },
        signal: controller.signal
      });
    } finally {
      clearTimeout(timeoutId);
    }
    if (!response.ok) throw new Error(`El servicio de búsqueda respondió ${response.status}.`);
    const results = await response.json();
    select.replaceChildren();
    results.forEach((result, index) => {
      if (!Array.isArray(result.boundingbox) || result.boundingbox.length !== 4) return;
      const [south, north, west, east] = result.boundingbox.map(Number);
      if (![west, south, east, north].every(Number.isFinite) || east <= west || north <= south) return;
      const option = new Option(result.display_name, String(index));
      option.dataset.bounds = JSON.stringify([west, south, east, north]);
      select.add(option);
    });
    if (select.options.length === 0) {
      select.add(new Option('No se encontraron regiones con límites descargables', ''));
      status.textContent = 'Prueba con el nombre de un país, provincia o ciudad.';
      return;
    }
    select.disabled = false;
    downloadButton.disabled = false;
    status.textContent = `${select.options.length} resultados. Elige uno para descargar sus segmentos de 5°; el tamaño puede ser grande.`;
  } catch (error) {
    console.error('Error al buscar regiones BRouter:', error);
    select.replaceChildren(new Option('No se pudo completar la búsqueda', ''));
    status.textContent = `No se pudo buscar la región: ${error.message}`;
  } finally {
    searchButton.disabled = false;
  }
}

async function descargarDatosBrouter() {
  const select = document.getElementById('selectRegionBrouter');
  const status = document.getElementById('estadoDatosBrouter');
  const selectedOption = select.selectedOptions[0];
  if (!selectedOption?.dataset.bounds) throw new Error('Busca y selecciona una región BRouter válida.');
  const bounds = JSON.parse(selectedOption.dataset.bounds);
  const region = { label: selectedOption.textContent, bounds };
  const tiles = tilesParaRegion(bounds);
  if (tiles.length === 0) throw new Error('La región seleccionada no contiene segmentos descargables.');
  if (!window.confirm(`Se iniciará la descarga de ${tiles.length} archivos de datos de ${region.label}. Los archivos pueden ocupar cientos de MB. ¿Continuar?`)) return;

  const button = document.getElementById('btnDescargarDatosBrouter');
  button.disabled = true;
  try {
    for (let index = 0; index < tiles.length; index++) {
      const filename = tiles[index];
      status.textContent = `Solicitando ${index + 1} de ${tiles.length}: ${filename}`;
      const url = `https://brouter.de/brouter/segments4/${filename}`;
      if (isNativeAndroid) {
        await EkdNav.downloadBrouterSegment({ url, filename });
      } else {
        const link = document.createElement('a');
        link.href = url;
        link.download = filename;
        link.rel = 'noopener';
        document.body.appendChild(link);
        link.click();
        link.remove();
      }
      if (index < tiles.length - 1) {
        await new Promise(resolve => setTimeout(resolve, 700));
      }
    }
    const downloadLocation = isNativeAndroid ? 'la carpeta Descargas de Android' : 'las descargas del navegador';
    status.textContent = `Se solicitaron los ${tiles.length} archivos de ${region.label}. Revisa ${downloadLocation}. Los .rd5 no se usan para calcular rutas offline.`;
  } finally {
    button.disabled = false;
  }
}

// --- Guardar Mapa Vectorial Offline ---
function tileX(longitude, zoom) {
  return Math.floor((longitude + 180) / 360 * (2 ** zoom));
}

function tileY(latitude, zoom) {
  const radians = Math.max(-85.05112878, Math.min(85.05112878, latitude)) * Math.PI / 180;
  return Math.floor((1 - Math.asinh(Math.tan(radians)) / Math.PI) / 2 * (2 ** zoom));
}

async function crearListaTeselas(bounds) {
  const response = await fetch('https://tiles.openfreemap.org/planet');
  if (!response.ok) throw new Error(`El servicio de mapas respondió ${response.status}.`);
  const tileJson = await response.json();
  const template = tileJson.tiles?.[0];
  if (!template || !Number.isInteger(tileJson.minzoom) || !Number.isInteger(tileJson.maxzoom)) {
    throw new Error('El servicio de mapas vectoriales devolvió una configuración no válida.');
  }

  const urls = new Set();
  for (let zoom = tileJson.minzoom; zoom <= tileJson.maxzoom; zoom++) {
    const tileCount = 2 ** zoom;
    const minX = tileX(bounds.getWest(), zoom);
    const maxX = tileX(bounds.getEast(), zoom);
    const minY = tileY(bounds.getNorth(), zoom);
    const maxY = tileY(bounds.getSouth(), zoom);
    for (let x = minX; x <= maxX; x++) {
      const wrappedX = ((x % tileCount) + tileCount) % tileCount;
      for (let y = minY; y <= maxY; y++) {
        if (y >= 0 && y < tileCount) {
          urls.add(template.replace('{z}', zoom).replace('{x}', wrappedX).replace('{y}', y));
          if (urls.size > 2000) {
            throw new Error('La zona es demasiado grande. Acerca el mapa y vuelve a intentarlo.');
          }
        }
      }
    }
  }
  return Array.from(urls);
}

async function serviceWorkerMessage(type, data = {}, timeoutMs = 120000) {
  const registration = await navigator.serviceWorker.ready;
  const worker = navigator.serviceWorker.controller || registration.active;
  if (!worker) throw new Error('El Service Worker no está activo. Recarga la app e inténtalo de nuevo.');

  return new Promise((resolve, reject) => {
    const channel = new MessageChannel();
    const timer = setTimeout(() => {
      channel.port1.close();
      reject(new Error('Se agotó el tiempo al procesar el mapa offline.'));
    }, timeoutMs);
    channel.port1.onmessage = event => {
      clearTimeout(timer);
      channel.port1.close();
      if (event.data?.error) {
        reject(new Error(event.data.error));
        return;
      }
      resolve(event.data);
    };
    try {
      worker.postMessage({ type, ...data }, [channel.port2]);
    } catch (error) {
      clearTimeout(timer);
      channel.port1.close();
      reject(error);
    }
  });
}

async function guardarMapaOffline() {
  if (!mapReady) return;
  if (!('serviceWorker' in navigator)) {
    alert('Este navegador no permite guardar mapas offline.');
    return;
  }

  const button = document.getElementById('btnGuardarOffline');
  button.disabled = true;
  document.getElementById('btnBorrarOffline').disabled = true;
  button.textContent = 'Descargando...';
  try {
    const urls = await crearListaTeselas(map.getBounds());
    const result = await serviceWorkerMessage('CACHE_VECTOR_TILES', { urls }, 600000);
    const sizeMb = (result.bytesUsed / 1000000).toFixed(1);
    const limitMessage = result.limitReached ? ' Se alcanzó el límite de 75 MB.' : '';
    const failureMessage = result.failed ? ` ${result.failed} teselas no se pudieron guardar.` : '';
    alert(`Mapa vectorial disponible offline: ${result.cached} teselas, ${sizeMb} MB de 75 MB.${limitMessage}${failureMessage}`);
  } catch (error) {
    console.error('Error al guardar el mapa offline:', error);
    alert(`No se pudo guardar el mapa offline: ${error.message}`);
  } finally {
    button.disabled = false;
    document.getElementById('btnBorrarOffline').disabled = false;
    button.textContent = 'Descargar mapa';
  }
}

async function borrarMapaOffline() {
  const button = document.getElementById('btnBorrarOffline');
  button.disabled = true;
  document.getElementById('btnGuardarOffline').disabled = true;
  try {
    await serviceWorkerMessage('CLEAR_VECTOR_TILES');
    alert('Se borraron los mapas vectoriales descargados.');
  } catch (error) {
    console.error('Error al borrar el mapa offline:', error);
    alert(`No se pudo borrar el mapa offline: ${error.message}`);
  } finally {
    button.disabled = false;
    document.getElementById('btnGuardarOffline').disabled = false;
  }
}

document.addEventListener('DOMContentLoaded', () => {
  document.addEventListener('visibilitychange', () => {
    if (isNativeAndroid && document.visibilityState === 'visible') {
      EkdNav.getNavigationStatus()
        .then(aplicarEstadoNavegacionNativo)
        .catch(error => console.error('No se pudo actualizar la navegación Android:', error));
    }
  });

  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('./sw.js').catch((err) => {
      console.error('Error al registrar el Service Worker:', err);
    });
  }

  if (isNativeAndroid) {
    document.getElementById('backgroundNotice').hidden = true;
    EkdNav.addListener('navigationUpdate', update => {
      if (navigationRunning) actualizarPosicionDesdeNativo(update);
      else if (update.running) {
        EkdNav.getNavigationStatus()
          .then(aplicarEstadoNavegacionNativo)
          .catch(error => console.error('No se pudo recuperar el estado Android:', error));
      }
    }).catch(error => console.error('No se pudo escuchar la navegación Android:', error));
    EkdNav.addListener('routeUpdated', route => {
      if (!navigationRunning) {
        EkdNav.getNavigationStatus()
          .then(aplicarEstadoNavegacionNativo)
          .catch(error => console.error('No se pudo recuperar la ruta Android:', error));
        return;
      }
      if (!Array.isArray(route.points) || route.points.length < 2) return;
      gpxNav.points = route.points;
      gpxNav.turns = route.turns || [];
      progressMeters = Number(route.progressMeters) || 0;
      routeEstimatedSeconds = null;
      routeDistances = [0];
      for (let i = 1; i < gpxNav.points.length; i++) {
        routeDistances.push(routeDistances[i - 1] + gpxNav.haversine(gpxNav.points[i - 1], gpxNav.points[i]));
      }
      prepararPerfilRuta(gpxNav.points);
      actualizarResumenNavegacion(route.info || '');
      routeColor = route.routeColor || '#2979ff';
      dibujarRuta(gpxNav.points, routeColor);
    }).catch(error => console.error('No se pudo escuchar la ruta recalculada:', error));
    EkdNav.addListener('navigationError', event => {
      document.getElementById('infoGiro').textContent = event.message || 'Error del servicio de navegación Android.';
      if (navigationRunning && nativeNavigationActive && watchId === null) {
        nativeNavigationActive = false;
        iniciarSeguimientoGpsWeb();
      }
    }).catch(error => console.error('No se pudo escuchar errores de navegación:', error));
    EkdNav.addListener('rerouteError', event => {
      document.getElementById('infoGiro').textContent = event.message || 'No se pudo recalcular la ruta.';
    }).catch(error => console.error('No se pudo escuchar errores de recálculo:', error));
    EkdNav.getNavigationStatus()
      .then(aplicarEstadoNavegacionNativo)
      .catch(error => console.error('No se pudo recuperar el estado de navegación:', error));
  }

  initMap();
  setupAutocomplete();

  if (isNativeAndroid) {
    document.getElementById('nativeConnectionControls').classList.remove('hidden');
  } else {
    document.getElementById('nativeConnectionControls').remove();
    document.getElementById('dialogConexion').remove();
  }

  if (isNativeAndroid) {
    const btnConectar = document.getElementById('btnConectar');
    const dialogConexion = document.getElementById('dialogConexion');
    const btnPairConnect = document.getElementById('btn-pair-connect');
    const btnCerrarConexion = document.getElementById('btnCerrarConexion');
    const inputMac = document.getElementById('manual-mac-input');

    bluetooth.addEventListener('statuschange', event => {
      const status = event.detail.status;
      const statusLabel = document.getElementById('estadoConexion');
      if (status === 'disconnected') {
        bluetoothReady = false;
        statusLabel.textContent = '● Desconectado';
        statusLabel.style.color = '#ff8a80';
        btnConectar.style.display = '';
      } else if (status === 'connecting' || status === 'reconnecting') {
        statusLabel.textContent = '● Conectando...';
        statusLabel.style.color = '#ffca28';
      } else if (status === 'connected') {
        bluetoothReady = true;
        statusLabel.textContent = '● EKD01 Conectado';
        statusLabel.style.color = '#00c853';
        btnConectar.style.display = 'none';
      }
    });

    inputMac.addEventListener('input', () => pairing.validateManualAddress());
    inputMac.addEventListener('keydown', event => {
      if (event.key === 'Enter' && !btnPairConnect.disabled) btnPairConnect.click();
    });

    document.getElementById('btn-retry-camera').addEventListener('click', () => pairing.start());
    btnCerrarConexion.addEventListener('click', () => {
      pairing.stop();
      dialogConexion.close();
    });
    dialogConexion.addEventListener('close', () => pairing.stop());

    btnConectar.addEventListener('click', () => {
      dialogConexion.showModal();
      pairing.start();
    });

    btnPairConnect.addEventListener('click', async () => {
      btnPairConnect.disabled = true;
      btnConectar.disabled = true;
      try {
        document.getElementById('estadoConexion').textContent = '● Conectando...';
        await bluetooth.connectNative(inputMac.value);
        bluetoothReady = true;

        document.getElementById('estadoConexion').textContent = '● EKD01 Conectado';
        document.getElementById('estadoConexion').style.color = '#00c853';
        btnConectar.style.display = 'none';
        bluetooth.startHeartbeat(15000);
        pairing.stop();
        dialogConexion.close();
      } catch (err) {
        bluetoothReady = false;
        document.getElementById('estadoConexion').textContent = '● Desconectado';
        document.getElementById('estadoConexion').style.color = '#ff8a80';
        if (bluetooth.connected) await bluetooth.disconnect();
        document.getElementById('qr-status').textContent = `No se pudo conectar: ${err.message}`;
        alert('Error BLE: ' + err.message);
      } finally {
        btnPairConnect.disabled = false;
        btnConectar.disabled = false;
      }
    });
  }

  const btnIr = document.getElementById('btnIr');
  if (btnIr) {
    btnIr.addEventListener('click', async () => {
      const inputDestino = document.getElementById('inputBuscador');
      const query = inputDestino.value.trim();
      if (!selectedDestination || selectedDestination.name !== query) {
        if (query.length < 3) {
          alert('Escribe un destino o selecciónalo en el mapa.');
          return;
        }
        btnIr.disabled = true;
        btnIr.textContent = 'Buscando destino...';
        try {
          selectedDestination = await buscarDestinoPorTexto(query);
          inputDestino.value = selectedDestination.name;
          map?.flyTo({ center: [selectedDestination.lon, selectedDestination.lat], zoom: 14 });
          actualizarMarcadorDestino(selectedDestination);
        } catch (err) {
          alert(`No se pudo encontrar el destino: ${err.message}`);
          return;
        } finally {
          btnIr.disabled = false;
          btnIr.textContent = 'Buscar ruta';
        }
      }
      calcularRutaYNavegar(selectedDestination.lat, selectedDestination.lon);
    });
  }

  const regionQuery = document.getElementById('inputRegionBrouter');
  document.getElementById('btnBuscarRegionBrouter').addEventListener('click', buscarRegionesBrouter);
  regionQuery.addEventListener('keydown', event => {
    if (event.key === 'Enter') {
      event.preventDefault();
      buscarRegionesBrouter();
    }
  });
  document.getElementById('selectRegionBrouter').addEventListener('change', event => {
    document.getElementById('btnDescargarDatosBrouter').disabled =
      !event.target.selectedOptions[0]?.dataset.bounds;
  });
  document.getElementById('selectRouteProfile').addEventListener('change', event => {
    routeProfile = event.target.value;
  });
  document.getElementById('btnDescargarDatosBrouter').addEventListener('click', () => {
    descargarDatosBrouter().catch(error => {
      console.error('Error al descargar datos BRouter:', error);
      document.getElementById('estadoDatosBrouter').textContent = `No se pudieron iniciar las descargas: ${error.message}`;
    });
  });

  const inputGpx = document.getElementById('inputGpx');
  if (inputGpx) {
    inputGpx.addEventListener('change', (e) => {
      const file = e.target.files[0];
      if (!file) return;
      inputGpx.value = '';
      const reader = new FileReader();
      reader.onload = (event) => {
        try {
          const navData = gpxNav.loadGpxText(event.target.result);
          routeRequestVersion++;
          automaticReroutingEnabled = false;
          routeEstimatedSeconds = null;
          const destination = navData.points[navData.points.length - 1];
          activeDestination = { lat: destination.lat, lon: destination.lon, name: 'Destino de la ruta' };
          simulatedIndex = 0;
          progressMeters = 0;
          document.getElementById('btnAbrirNavegacion').disabled = false;
          actualizarMarcadorDestino(activeDestination);
          dibujarRuta(navData.points, '#00c853');
          iniciarSeguimientoGps();
          abrirPantallaNavegacion();
        } catch (err) {
          alert('Error al leer GPX: ' + err.message);
        }
      };
      reader.readAsText(file);
    });
  }

  const btnPararNav = document.getElementById('btnPararNav');
  if (btnPararNav) {
    btnPararNav.addEventListener('click', detenerNavegacion);
  }

  document.getElementById('btnRecalcularRuta').addEventListener('click', recalcularRuta);
  document.getElementById('btnAbrirNavegacion').addEventListener('click', abrirPantallaNavegacion);
  document.getElementById('btnVolverPlanificacion').addEventListener('click', volverAPlanificacion);
  document.getElementById('btnVolverPlanificacionFooter').addEventListener('click', volverAPlanificacion);
  document.getElementById('btnPararNavPantalla').addEventListener('click', detenerNavegacion);
  document.getElementById('btnRecalcularNav').addEventListener('click', recalcularRuta);
  document.getElementById('btnVozNav').addEventListener('click', () => document.getElementById('btnVoz').click());

  const btnGuardarOffline = document.getElementById('btnGuardarOffline');
  if (btnGuardarOffline) {
    btnGuardarOffline.addEventListener('click', guardarMapaOffline);
  }

  document.getElementById('btnBorrarOffline').addEventListener('click', borrarMapaOffline);
  const btnVoz = document.getElementById('btnVoz');
  btnVoz.addEventListener('click', () => {
    voiceEnabled = !voiceEnabled;
    if (!voiceEnabled && 'speechSynthesis' in window) window.speechSynthesis.cancel();
    actualizarBotonVoz();
    if (isNativeAndroid) {
      EkdNav.setVoiceEnabled({ enabled: voiceEnabled })
        .catch(error => console.error('No se pudo cambiar la voz de navegación:', error));
    }
  });

});