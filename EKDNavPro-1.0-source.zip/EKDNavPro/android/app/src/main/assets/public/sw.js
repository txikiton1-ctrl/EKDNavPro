const CACHE_APP = 'bidebizi-web-v3';
const CACHE_MAPAS = 'ekdnav-vector-map-v2';
const CACHE_LIMIT_BYTES = 75 * 1000 * 1000;
let knownCacheBytes = null;
let cacheWriteQueue = Promise.resolve();

const ASSETS = [
  './',
  './index.html',
  './manifest.json',
  './icons/icon-192.png',
  './icons/icon-512.png'
];

async function getCacheSize(cache) {
  let total = 0;
  for (const request of await cache.keys()) {
    const response = await cache.match(request);
    if (response) total += (await response.clone().arrayBuffer()).byteLength;
  }
  return total;
}

function serializeCacheWrite(operation) {
  const result = cacheWriteQueue.then(operation);
  cacheWriteQueue = result.catch(() => {});
  return result;
}

async function cacheMapResource(cache, request, response) {
  const size = (await response.clone().arrayBuffer()).byteLength;
  await serializeCacheWrite(async () => {
    if (knownCacheBytes === null) knownCacheBytes = await getCacheSize(cache);
    if (knownCacheBytes + size > CACHE_LIMIT_BYTES) return;
    await cache.put(request, response.clone());
    knownCacheBytes += size;
  });
}

self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE_APP).then(cache => cache.addAll(ASSETS)));
  self.skipWaiting();
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys => Promise.all(
      keys.filter(key =>
        (key.startsWith('bidebizi-web-') && key !== CACHE_APP) ||
        (key.startsWith('ekdnav-') && key !== CACHE_APP && key !== CACHE_MAPAS) ||
        key === 'ekd01-clean-v4' ||
        key === 'ekd01-tiles-v1'
      )
        .map(key => caches.delete(key))
    ))
  );
  self.clients.claim();
});

self.addEventListener('fetch', event => {
  const requestUrl = new URL(event.request.url);
  if (requestUrl.hostname === 'unpkg.com' &&
      /^\/maplibre-gl@5\.6\.1\/dist\/maplibre-gl\.(js|css)$/.test(requestUrl.pathname)) {
    event.respondWith((async () => {
      const cache = await caches.open(CACHE_APP);
      const cached = await cache.match(event.request);
      try {
        const response = await fetch(event.request);
        if (response.ok) await cache.put(event.request, response.clone());
        return response;
      } catch (error) {
        if (cached) return cached;
        throw error;
      }
    })());
    return;
  }

  if (requestUrl.hostname === 'tiles.openfreemap.org') {
    event.respondWith((async () => {
      const cache = await caches.open(CACHE_MAPAS);
      const cached = await cache.match(event.request);
      if (cached) return cached;
      try {
        const response = await fetch(event.request);
        const isVectorTile = /^\/planet\/[^/]+\/\d+\/\d+\/\d+\.pbf$/.test(requestUrl.pathname);
        if (response.ok && !isVectorTile) await cacheMapResource(cache, event.request, response);
        return response;
      } catch (error) {
        if (cached) return cached;
        throw error;
      }
    })());
    return;
  }

  if (event.request.mode === 'navigate' || requestUrl.pathname.endsWith('/manifest.json')) {
    event.respondWith((async () => {
      const cache = await caches.open(CACHE_APP);
      const cacheKey = event.request.mode === 'navigate'
        ? new Request(new URL('./index.html', self.registration.scope))
        : event.request;
      try {
        const response = await fetch(event.request);
        if (event.request.method === 'GET' && requestUrl.origin === self.location.origin && response.ok) {
          await cache.put(cacheKey, response.clone());
        }
        return response;
      } catch (error) {
        const cached = await cache.match(event.request) || await cache.match(cacheKey);
        if (cached) return cached;
        throw error;
      }
    })());
    return;
  }

  event.respondWith((async () => {
    const cached = await caches.match(event.request);
    if (cached) return cached;
    const response = await fetch(event.request);
    if (event.request.method === 'GET' && requestUrl.origin === self.location.origin && response.ok) {
      const cache = await caches.open(CACHE_APP);
      await cache.put(event.request, response.clone());
    }
    return response;
  })());
});

self.addEventListener('message', event => {
  const { type } = event.data || {};
  if (type === 'CLEAR_VECTOR_TILES') {
    event.waitUntil((async () => {
      await caches.delete(CACHE_MAPAS);
      await caches.delete('ekd01-tiles-v1');
      knownCacheBytes = 0;
      event.ports[0]?.postMessage({ cleared: true });
    })());
    return;
  }
  if (type !== 'CACHE_VECTOR_TILES') return;

  event.waitUntil((async () => {
    try {
      const urls = Array.isArray(event.data.urls) ? event.data.urls.slice(0, 2000) : [];
      const cache = await caches.open(CACHE_MAPAS);
      await serializeCacheWrite(async () => {
        if (knownCacheBytes === null) knownCacheBytes = await getCacheSize(cache);
      });
      let cached = 0;
      let failed = 0;
      let limitReached = false;

      for (const url of urls) {
        const parsed = new URL(url);
        if (parsed.hostname !== 'tiles.openfreemap.org' ||
            !/^\/planet\/[^/]+\/\d+\/\d+\/\d+\.pbf$/.test(parsed.pathname)) {
          failed++;
          continue;
        }
        const request = new Request(parsed.href);
        if (await cache.match(request)) {
          cached++;
          continue;
        }
        try {
          const response = await fetch(request);
          if (!response.ok) throw new Error(`HTTP ${response.status}`);
          const body = await response.clone().arrayBuffer();
          const stored = await serializeCacheWrite(async () => {
            if (knownCacheBytes === null) knownCacheBytes = await getCacheSize(cache);
            if (knownCacheBytes + body.byteLength > CACHE_LIMIT_BYTES) return false;
            await cache.put(request, response);
            knownCacheBytes += body.byteLength;
            return true;
          });
          if (!stored) {
            limitReached = true;
            break;
          }
          cached++;
        } catch (error) {
          failed++;
        }
      }

      event.ports[0]?.postMessage({ cached, failed, bytesUsed: knownCacheBytes, limitReached });
    } catch (error) {
      event.ports[0]?.postMessage({ error: `No se pudo acceder a la caché: ${error.message}` });
    }
  })());
});
